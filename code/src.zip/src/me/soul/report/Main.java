package me.soul.report;

import me.soul.report.events.ChatListener;
import me.soul.report.events.Commands;
import me.soul.report.events.InvClickListener;
import me.soul.report.events.JoinListener;
import me.soul.report.events.LeftListener;
import me.soul.report.events.LoginListener;
import me.soul.report.events.PluginListener;
import me.soul.report.files.Languages;
import me.soul.report.files.Reports;
import me.soul.report.files.SolvedReports;
import me.soul.report.files.Status;
import me.soul.report.utils.DBS;
import me.soul.report.utils.Gui;
import me.soul.report.utils.MySql;
import me.soul.report.utils.PluginMessages;
import me.soul.report.utils.StatusUtils;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

   private static Main main;
   private static Languages languages;
   private static Reports reportsLog;
   private static SolvedReports solvedReportsLog;
   private static Gui guiUtil;
   private static StatusUtils statusUtil;
   private static DBS database;
   private static MySql mysql;
   private static PluginMessages pl;
   private static Status status;


   public void onEnable() {
      this.saveDefaultConfig();
      main = this;
      languages = new Languages();
      reportsLog = new Reports();
      solvedReportsLog = new SolvedReports();
      status = new Status();
      statusUtil = new StatusUtils();
      database = new DBS();
      mysql = new MySql();
      guiUtil = new Gui();
      pl = new PluginMessages();
      if(this.hasReloaded()) {
         this.getServer().getConsoleSender().sendMessage("§cAdvancedReportSystem dont support reloads, plugin stopped working.");
         this.getServer().getConsoleSender().sendMessage("§cRestart the server to re-active the plugin.");
         this.setEnabled(false);
      }

      this.getConfig().options().copyDefaults(true);
      this.saveDefaultConfig();
      getLanguages().setUp(this);
      if(this.getConfig().getBoolean("Settings.mysql")) {
         try {
            mysql.getMySQL();
            mysql.connect();
            mysql.createReportsTable();
            mysql.createStatusTable();
            mysql.createSolvedReportsTable();
         } catch (Exception var2) {
            this.getServer().getConsoleSender().sendMessage("§cError while connecting to mysql database");
            this.getServer().getConsoleSender().sendMessage("§cPlease, be sure that mysql infos are correct");
            this.getServer().getConsoleSender().sendMessage("§cAdvancedReportSystem disabled");
            this.setEnabled(false);
         }
      } else {
         getReportsLog().setUp(this);
         getStatusLog().setUp(this);
         getSolvedReportsLog().setUp(this);
      }

      this.getCommand("reports").setExecutor(new Commands());
      this.getCommand("rps").setExecutor(new Commands());
      this.getCommand("report").setExecutor(new Commands());
      this.getCommand("reviewed").setExecutor(new Commands());
      this.getServer().getPluginManager().registerEvents(new InvClickListener(), this);
      this.getServer().getPluginManager().registerEvents(new ChatListener(), this);
      this.getServer().getPluginManager().registerEvents(new LeftListener(), this);
      this.getServer().getPluginManager().registerEvents(new LoginListener(), this);
      this.getServer().getPluginManager().registerEvents(new JoinListener(), this);
      Bukkit.getServer().getMessenger().registerOutgoingPluginChannel(this, "reports:reportsystem");
      Bukkit.getServer().getMessenger().registerIncomingPluginChannel(this, "reports:reportsystem", new PluginListener());
      this.getServer().getConsoleSender().sendMessage("§aAdvancedReportSystem has been sucessfully enabled.");
   }

   public void onDisable() {
      if(this.getConfig().getBoolean("Settings.mysql")) {
         getDBS().disableServers();
      }

   }

   public boolean hasReloaded() {
      return !Bukkit.getOnlinePlayers().isEmpty();
   }

   public static Main getInstance() {
      return main;
   }

   public static Languages getLanguages() {
      return languages;
   }

   public static Reports getReportsLog() {
      return reportsLog;
   }

   public static Gui getGui() {
      return guiUtil;
   }

   public static StatusUtils getStatus() {
      return statusUtil;
   }

   public static DBS getDBS() {
      return database;
   }

   public static MySql getSql() {
      return mysql;
   }

   public static PluginMessages getPluginMessages() {
      return pl;
   }

   public static Status getStatusLog() {
      return status;
   }

   public static SolvedReports getSolvedReportsLog() {
      return solvedReportsLog;
   }
}
