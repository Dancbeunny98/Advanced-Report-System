package me.soul.report.events;

import java.util.HashMap;
import me.soul.report.Main;
import me.soul.report.events.Commands;
import me.soul.report.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChatEvent;

public class ChatListener implements Listener {

   public static HashMap other = new HashMap();
   public static HashMap comment = new HashMap();
   public static HashMap ban = new HashMap();
   public static HashMap kick = new HashMap();
   public static HashMap mute = new HashMap();


   @EventHandler
   public void onPlayerChat(PlayerChatEvent var1) {
      Player var2 = var1.getPlayer();
      if(other.containsKey(var2)) {
         Player var5 = (Player)other.get(var2);
         String var4 = var1.getMessage();
         if(var4.length() - 1 < 4) {
            var2.sendMessage("");
            Logger.log(var2, "short_reason");
            var2.sendMessage("");
            var1.setCancelled(true);
            return;
         }

         if(var4.length() - 1 > 15) {
            var2.sendMessage("");
            Logger.log(var2, "long_reason");
            var2.sendMessage("");
            var1.setCancelled(true);
            return;
         }

         if(var4.contains("_") || var4.contains("-") || var4.contains("#") || var4.contains("*") || var4.contains("°") || var4.contains("§") || var4.contains("@")) {
            var2.sendMessage("");
            Logger.log(var2, "symbols");
            var2.sendMessage("");
            var1.setCancelled(true);
            return;
         }

         Main.getReportsLog().addReport(var5, var4, Main.getInstance().getConfig().getString("Server"));
         Main.getPluginMessages().sendReport(var2.getName(), var5.getName(), var4, Main.getInstance().getConfig().getString("Server"));
         Commands.addCooldown(var2);
         other.remove(var2);
         var1.setCancelled(true);
      }

      String var51;
      if(comment.containsKey(var2)) {
         var51 = var1.getMessage();
         if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
            Main.getDBS().removeReport(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer((String)comment.get(var2)))?Bukkit.getPlayer((String)comment.get(var2)).getUniqueId():Bukkit.getOfflinePlayer((String)comment.get(var2)).getUniqueId());
            Main.getDBS().removeStatus(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer((String)comment.get(var2)))?Bukkit.getPlayer((String)comment.get(var2)).getUniqueId():Bukkit.getOfflinePlayer((String)comment.get(var2)).getUniqueId());
            Main.getDBS().addSolvedReport(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer((String)comment.get(var2)))?Bukkit.getPlayer((String)comment.get(var2)).getUniqueId():Bukkit.getOfflinePlayer((String)comment.get(var2)).getUniqueId(), var2.getName(), var51.replace(" ", "_"));
         } else {
            Main.getReportsLog().removeReport((String)comment.get(var2));
            Main.getStatusLog().removeReview((String)comment.get(var2));
            Main.getSolvedReportsLog().addSolvedReport(var2.getName(), var51);
         }

         Main.getPluginMessages().sendCloseReportMessage(var2.getName(), (String)comment.get(var2), var51, Main.getInstance().getConfig().getString("Server"));
         var1.setCancelled(true);
         comment.remove(var2);
      }

      if(ban.containsKey(var2)) {
         var51 = var1.getMessage();
         Bukkit.dispatchCommand(var2, Main.getInstance().getConfig().getString("Settings.ban_command").replace("%player%", ((String)ban.get(var2)).replace("%reason%", var51)));
         var1.setCancelled(true);
         ban.remove(var2);
      }

      if(kick.containsKey(var2)) {
         var51 = var1.getMessage();
         Bukkit.dispatchCommand(var2, Main.getInstance().getConfig().getString("Settings.kick_command").replace("%player%", ((String)kick.get(var2)).replace("%reason%", var51)));
         var1.setCancelled(true);
         kick.remove(var2);
      }

      if(mute.containsKey(var2)) {
         var51 = var1.getMessage();
         Bukkit.dispatchCommand(var2, Main.getInstance().getConfig().getString("Settings.mute_command").replace("%player%", ((String)mute.get(var2)).replace("%reason%", var51)));
         var1.setCancelled(true);
         mute.remove(var2);
      }

   }
}
