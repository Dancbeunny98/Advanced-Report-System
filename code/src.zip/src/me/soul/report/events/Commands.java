package me.soul.report.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import me.soul.report.Main;
import me.soul.report.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Commands implements CommandExecutor {

   static ArrayList cooldown = new ArrayList();
   static HashMap reporting = new HashMap();


   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      Player var5;
      if(var3.equalsIgnoreCase("reviewed")) {
         if(!(var1 instanceof Player)) {
            var1.sendMessage("");
            Logger.log((Player)var1, "only_players");
            var1.sendMessage("");
            return false;
         }

         if(!var1.hasPermission("reportsystem.admin")) {
            var1.sendMessage("");
            Logger.log((Player)var1, "permission");
            var1.sendMessage("");
            return false;
         }

         var5 = (Player)var1;
         if(Main.getStatus().hasReview(var5.getName())) {
            if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
               if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(UUID.fromString(Main.getStatus().getTarget(var5.getName()))))) {
                  Main.getGui().createPlayerManagerGui(var5, Bukkit.getPlayer(UUID.fromString(Main.getStatus().getTarget(var5.getName()))));
               } else {
                  Main.getGui().createOfflinePlayerManagerGui(var5, Bukkit.getOfflinePlayer(UUID.fromString(Main.getStatus().getTarget(var5.getName()))));
               }
            } else if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(UUID.fromString(Main.getStatus().getTarget(var5.getName()))))) {
               Main.getGui().createPlayerManagerGui(var5, Bukkit.getPlayer(Main.getStatusLog().getTarget(var5.getName())));
            } else {
               Main.getGui().createOfflinePlayerManagerGui(var5, Bukkit.getOfflinePlayer(Main.getStatusLog().getTarget(var5.getName())));
            }
         } else {
            var1.sendMessage("");
            Logger.log((Player)var1, "no_review");
            var1.sendMessage("");
         }
      }

      if(var3.equalsIgnoreCase("report")) {
         if(!(var1 instanceof Player)) {
            var1.sendMessage("");
            Logger.log((Player)var1, "only_players");
            var1.sendMessage("");
            return false;
         }

         var5 = (Player)var1;
         if(this.hasCooldown(var5) && !var5.hasPermission("reportsystem.bypass")) {
            var1.sendMessage("");
            Logger.log(var5, "cooldown");
            var1.sendMessage("");
            return false;
         }

         if(var4.length == 0) {
            var1.sendMessage("");
            Logger.log(var5, "please");
            Logger.log(var5, "reporttype1");
            Logger.log(var5, "reporttype2");
            var1.sendMessage("");
            return false;
         }

         if(Bukkit.getPlayer(var4[0]) == null) {
            if(Main.getInstance().getConfig().getBoolean("Settings.prefix")) {
               var5.sendMessage(Main.getLanguages().getLanguages().getString("prefix").replace("&", "§") + Main.getLanguages().getLanguages().getString("unknown_player").replace("&", "§").replace("%player%", var5.getName()));
            } else {
               var5.sendMessage(Main.getLanguages().getLanguages().getString("unknown_player").replace("&", "§").replace("%player%", var5.getName()));
            }

            return false;
         }

         Player var6 = Bukkit.getPlayer(var4[0]);
         if(var4.length == 1) {
            Main.getGui().createReportGui(var5, var6);
            addReporting(var5, var6);
            return false;
         }

         String var7 = "";

         for(int var8 = 1; var8 < var4.length; ++var8) {
            var7 = var7 + var4[var8] + " ";
         }

         if(var7.length() - 1 < 4) {
            var1.sendMessage("");
            Logger.log(var5, "short_reason");
            var1.sendMessage("");
            return false;
         }

         if(var7.length() - 1 > 15) {
            var1.sendMessage("");
            Logger.log(var5, "long_reason");
            var1.sendMessage("");
            return false;
         }

         if(var7.contains("_") || var7.contains("-") || var7.contains("#") || var7.contains("*") || var7.contains("°") || var7.contains("§") || var7.contains("@")) {
            var1.sendMessage("");
            Logger.log(var5, "symbols");
            var1.sendMessage("");
            return false;
         }

         Main.getReportsLog().addReport(var6, var7, Main.getInstance().getConfig().getString("Server"));
         Main.getPluginMessages().sendReport(var5.getName(), var6.getName(), var7, Main.getInstance().getConfig().getString("Server"));
         addCooldown(var5);
      }

      if(var3.equalsIgnoreCase("reports") || var3.equalsIgnoreCase("rps")) {
         if(!var1.hasPermission("reportsystem.admin")) {
            Logger.log((Player)var1, "permission");
            return false;
         }

         if(!(var1 instanceof Player)) {
            Logger.log((Player)var1, "only_players");
            return false;
         }

         var5 = (Player)var1;
         Main.getGui().createStaffGui(var5);
      }

      return false;
   }

   public static HashMap getReporting() {
      return reporting;
   }

   public static void addReporting(Player var0, Player var1) {
      if(!getReporting().containsKey(var0)) {
         getReporting().put(var0, var1);
      } else {
         getReporting().replace(var0, var1);
      }

   }

   public static void removeReporting(Player var0) {
      getReporting().remove(var0);
   }

   public static ArrayList getCooldown() {
      return cooldown;
   }

   public static void addCooldown(final Player var0) {
      getCooldown().add(var0);
      Bukkit.getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
         public void run() {
            Commands.removeReporting(var0);
         }
      }, (long)(20 * Main.getInstance().getConfig().getInt("Settings.cooldown")));
   }

   public boolean hasCooldown(Player var1) {
      return getCooldown().contains(var1);
   }
}
