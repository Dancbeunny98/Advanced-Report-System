package me.soul.report.events;

import me.soul.report.Main;
import me.soul.report.events.ChatListener;
import me.soul.report.events.Commands;
import me.soul.report.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.SkullMeta;

public class InvClickListener implements Listener {

   @EventHandler
   public void onReportClick(InventoryClickEvent var1) {
      if(var1.getCurrentItem() != null) {
         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(var2.getTitle().startsWith("§cReport")) {
            Player var4;
            String var5;
            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Killaura.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.Killaura.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Aimbot.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.Aimbot.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.AntiKnockback.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.AntiKnockback.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Speed.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.Speed.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Scaffold.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.Scaffold.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.WallHack.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.WallHack.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Phase.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.Phase.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.BugAbuse.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var5 = Main.getLanguages().getLanguages().getString("ReportGui.BugAbuse.name").replace("&", "§");
               Main.getReportsLog().addReport(var4, var5, Main.getInstance().getConfig().getString("Server"));
               Main.getPluginMessages().sendReport(var3.getName(), var4.getName(), var5, Main.getInstance().getConfig().getString("Server"));
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals(Main.getLanguages().getLanguages().getString("ReportGui.Other.name").replace("&", "§"))) {
               var4 = (Player)Commands.getReporting().get(var3);
               var3.sendMessage("");
               Logger.log(var3, "reason_other");
               var3.sendMessage("");
               ChatListener.other.put(var3, var4);
               Commands.addCooldown(var3);
               Commands.removeReporting(var3);
               var3.closeInventory();
            }

            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onStaffGuiClick(InventoryClickEvent var1) {
      if(var1.getCurrentItem() != null) {
         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(var2.getTitle().equalsIgnoreCase("§cStaff Gui")) {
            if(var1.getCurrentItem().getType() == Material.DIAMOND_BLOCK) {
               if(!Main.getGui().pages3.containsKey(var3)) {
                  Main.getGui();
                  Main.getGui().pages3.put(var3, Integer.valueOf(1));
               } else {
                  Main.getGui();
                  Main.getGui().pages3.remove(var3);
                  Main.getGui();
                  Main.getGui().pages3.put(var3, Integer.valueOf(1));
               }

               Main.getGui().createGlobalReportsList(var3);
            }

            if(var1.getCurrentItem().getType() == Material.REDSTONE_BLOCK) {
               Main.getGui();
               if(!Main.getGui().pages.containsKey(var3)) {
                  Main.getGui().pages.put(var3, Integer.valueOf(1));
               } else {
                  Main.getGui().pages.remove(var3);
                  Main.getGui().pages.put(var3, Integer.valueOf(1));
               }

               Main.getGui().createLocalReportsListGui(var3);
            }

            if(var1.getCurrentItem().getType() == Material.EMERALD_BLOCK) {
               if(!Main.getGui().pages2.containsKey(var3)) {
                  Main.getGui().pages2.put(var3, Integer.valueOf(1));
               } else {
                  Main.getGui().pages2.remove(var3);
                  Main.getGui().pages2.put(var3, Integer.valueOf(1));
               }

               Main.getGui().createSolvedReportsGui(var3);
            }

            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onGlobalReportsListClick(InventoryClickEvent var1) {
      if(var1.getClickedInventory() != null) {
         if(var1.getCurrentItem() == null || var1.getCurrentItem().getItemMeta() == null) {
            return;
         }

         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(!var2.getTitle().equalsIgnoreCase("§cGlobal reports")) {
            return;
         }

         if(var1.getCurrentItem().getType() == Material.BARRIER) {
            Main.getGui().createStaffGui(var3);
         }

         if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§cBack")) {
            Main.getGui().pages3.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages3.get(var3)).intValue() - 1));
            Main.getGui().createGlobalReportsList(var3);
         }

         if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§aForward")) {
            Main.getGui().pages3.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages3.get(var3)).intValue() + 1));
            Main.getGui().createGlobalReportsList(var3);
         }

         if(var1.getCurrentItem().getType() == Material.REDSTONE) {
            Main.getGui().createGlobalReportsList(var3);
            var3.sendMessage("");
            var3.sendMessage("§eThe page has been reloaded.");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.HOPPER) {
            Main.getGui().createConfirmGui3(var3);
         }

         if(var1.getCurrentItem().getType() == Material.PLAYER_HEAD) {
            SkullMeta var6 = (SkullMeta)var1.getCurrentItem().getItemMeta();
            if(!Main.getStatus().hasReview(var3.getName())) {
               Main.getStatus().setStatusReviewed(var6.getOwner(), var3.getName());
               if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var6.getOwner()))) {
                  Main.getGui().createPlayerManagerGui(var3, Bukkit.getPlayer(var6.getOwner()));
               } else {
                  Main.getGui().createOfflinePlayerManagerGui(var3, Bukkit.getOfflinePlayer(var6.getOwner()));
               }
            } else {
               var3.sendMessage("");
               var3.sendMessage("§cYou are already reviewing " + Main.getStatus().getTarget(var3.getName()) + ".");
               var3.sendMessage("");
            }
         }

         if(var1.getCurrentItem().getType() == Material.GOLD_BLOCK) {
            String[] var61 = var1.getCurrentItem().getItemMeta().getDisplayName().split(" ");
            String var5 = var61[0].replace("§e", "");
            if(!Main.getStatus().getReviewer(Bukkit.getPlayer(var5).getUniqueId()).equalsIgnoreCase(var3.getName())) {
               var3.sendMessage("");
               var3.sendMessage("§eThis report is already reviewed by " + Main.getStatus().getReviewer(Bukkit.getPlayer(var5).getUniqueId()) + ".");
               var3.sendMessage("");
               var1.setCancelled(true);
               return;
            }

            if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var5))) {
               Main.getGui().createPlayerManagerGui(var3, Bukkit.getPlayer(var5));
            } else {
               Main.getGui().createOfflinePlayerManagerGui(var3, Bukkit.getOfflinePlayer(var5));
            }
         }

         var1.setCancelled(true);
      }

   }

   @EventHandler
   public void onLocalReportsListClick(InventoryClickEvent var1) {
      if(var1.getCurrentItem() != null) {
         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(var2.getTitle().equalsIgnoreCase("§cLocal reports") && var1.getCurrentItem().getItemMeta() != null) {
            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§cBack")) {
               Main.getGui().pages.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages.get(var3)).intValue() - 1));
               Main.getGui().createLocalReportsListGui(var3);
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§aForward")) {
               Main.getGui().pages.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages.get(var3)).intValue() + 1));
               Main.getGui().createLocalReportsListGui(var3);
            }

            if(var1.getCurrentItem().getType() == Material.REDSTONE) {
               Main.getGui().createLocalReportsListGui(var3);
               var3.sendMessage("");
               var3.sendMessage("§eThe Page has been reloaded.");
               var3.sendMessage("");
            }

            if(var1.getCurrentItem().getType() == Material.PLAYER_HEAD) {
               SkullMeta var6 = (SkullMeta)var1.getCurrentItem().getItemMeta();
               if(!Main.getStatus().hasReview(var3.getName())) {
                  Main.getStatus().setStatusReviewed(var6.getOwner(), var3.getName());
                  if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var6.getOwner()))) {
                     Main.getGui().createPlayerManagerGui(var3, Bukkit.getPlayer(var6.getOwner()));
                  } else {
                     Main.getGui().createOfflinePlayerManagerGui(var3, Bukkit.getOfflinePlayer(var6.getOwner()));
                  }
               } else {
                  var3.sendMessage("");
                  var3.sendMessage("§cYou are already reviewing " + Main.getStatus().getTarget(var3.getName()) + ".");
                  var3.sendMessage("");
               }
            }

            if(var1.getCurrentItem().getType() == Material.GOLD_BLOCK) {
               String[] var61 = var1.getCurrentItem().getItemMeta().getDisplayName().split(" ");
               String var5 = var61[0].replace("§e", "");
               if(!Main.getStatus().getReviewer(Bukkit.getPlayer(var5).getUniqueId()).equalsIgnoreCase(var3.getName())) {
                  var3.sendMessage("");
                  var3.sendMessage("§eThis report is already reviewed by " + Main.getStatus().getReviewer(Bukkit.getPlayer(var5).getUniqueId()) + ".");
                  var3.sendMessage("");
                  var1.setCancelled(true);
                  return;
               }

               if(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var5))) {
                  Main.getGui().createPlayerManagerGui(var3, Bukkit.getPlayer(var5));
               } else {
                  Main.getGui().createOfflinePlayerManagerGui(var3, Bukkit.getOfflinePlayer(var5));
               }
            }

            if(var1.getCurrentItem().getType() == Material.HOPPER) {
               Main.getGui().createConfirmGui(var3);
            }

            if(var1.getCurrentItem().getType() == Material.BARRIER) {
               Main.getGui().createStaffGui(var3);
            }

            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onPlayerManagerGuiClick(InventoryClickEvent var1) {
      if(var1.getClickedInventory() != null) {
         if(var1.getCurrentItem() == null) {
            return;
         }

         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(!var2.getName().startsWith("§cManage")) {
            return;
         }

         String[] var4;
         String var5;
         if(var1.getCurrentItem().getType() == Material.WRITTEN_BOOK) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            ChatListener.comment.put(var3, var5);
            var3.closeInventory();
            var3.sendMessage("");
            var3.sendMessage("§aSpecify the report close reason");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.IRON_BOOTS) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            var3.sendMessage("");
            var3.sendMessage("§eYou have been teleported to " + var5);
            var3.sendMessage("");
            var3.teleport(Bukkit.getPlayer(var5));
         }

         if(var1.getCurrentItem().getType() == Material.ANVIL) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            ChatListener.ban.put(var3, var5);
            var3.closeInventory();
            var3.sendMessage("");
            var3.sendMessage("§cSpecify the ban reason");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.REDSTONE) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            ChatListener.kick.put(var3, var5);
            var3.closeInventory();
            var3.sendMessage("");
            var3.sendMessage("§cSpecify the kick reason");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.PAPER) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            ChatListener.mute.put(var3, var5);
            var3.closeInventory();
            var3.sendMessage("");
            var3.sendMessage("§cSpecify the mute reason");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.FEATHER) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            var3.sendMessage("");
            var3.sendMessage("§a" + var5 + " is currently in " + Main.getDBS().getServer(Bukkit.getPlayer(var5).getUniqueId()).toUpperCase() + ".");
            var3.sendMessage("");
         }

         if(var1.getCurrentItem().getType() == Material.HOPPER) {
            var4 = var2.getTitle().split(" ");
            var5 = var4[1].replace("§c", "");
            if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
               Main.getDBS().removeReport(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var5))?Bukkit.getPlayer(var5).getUniqueId():Bukkit.getOfflinePlayer(var5).getUniqueId());
               Main.getDBS().removeStatus(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var5))?Bukkit.getPlayer(var5).getUniqueId():Bukkit.getOfflinePlayer(var5).getUniqueId());
            } else {
               Main.getReportsLog().removeReport(var5);
               Main.getStatus().removeReviewBy(var3.getName());
            }

            var3.sendMessage("");
            var3.sendMessage("§eReport removed from the database.");
            var3.sendMessage("");
            var3.closeInventory();
         }

         if(var1.getCurrentItem().getType() == Material.LEGACY_STAINED_GLASS_PANE) {
            var3.sendMessage("");
            var3.sendMessage("§cError");
            var3.sendMessage("");
         }

         var1.setCancelled(true);
      }

   }

   @EventHandler
   public void onSolvedReportsGuiClick(InventoryClickEvent var1) {
      if(var1.getClickedInventory() != null) {
         if(var1.getCurrentItem() == null) {
            return;
         }

         Inventory var2 = var1.getClickedInventory();
         Player var3 = (Player)var1.getWhoClicked();
         if(var2.getTitle().equalsIgnoreCase("§2Solved reports")) {
            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§cBack")) {
               Main.getGui().pages2.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages2.get(var3)).intValue() - 1));
               Main.getGui().createSolvedReportsGui(var3);
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equals("§aForward")) {
               Main.getGui().pages2.replace(var3, Integer.valueOf(((Integer)Main.getGui().pages2.get(var3)).intValue() + 1));
               Main.getGui().createSolvedReportsGui(var3);
            }

            if(var1.getCurrentItem().getType() == Material.REDSTONE) {
               Main.getGui().createSolvedReportsGui(var3);
               var3.sendMessage("");
               var3.sendMessage("§eThe page has been reloaded.");
               var3.sendMessage("");
            }

            if(var1.getCurrentItem().getType() == Material.HOPPER) {
               Main.getGui().createConfirmGui2(var3);
            }

            if(var1.getCurrentItem().getType() == Material.BARRIER) {
               Main.getGui().createStaffGui(var3);
            }

            var1.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onConfirmGuiClick(InventoryClickEvent var1) {
      try {
         if(var1.getClickedInventory() != null) {
            if(var1.getCurrentItem() == null) {
               return;
            }

            Inventory var2 = var1.getClickedInventory();
            Player var3 = (Player)var1.getWhoClicked();
            if(!var2.getTitle().equalsIgnoreCase("§cAre you sure?")) {
               return;
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aYes")) {
               Main.getDBS().clearLocalReportsTable();
               var3.closeInventory();
               var3.sendMessage("");
               var3.sendMessage("§eAll local reports have been removed.");
               var3.sendMessage("");
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cNo")) {
               Main.getGui().createLocalReportsListGui(var3);
            }

            var1.setCancelled(true);
         }
      } catch (Exception var4) {
         ;
      }

   }

   @EventHandler
   public void onConfirmGuiClick2(InventoryClickEvent var1) {
      try {
         if(var1.getClickedInventory() != null) {
            if(var1.getCurrentItem() == null) {
               return;
            }

            Inventory var2 = var1.getClickedInventory();
            Player var3 = (Player)var1.getWhoClicked();
            if(!var2.getTitle().equalsIgnoreCase("§cAre you sure? ")) {
               return;
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aYes")) {
               if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
                  Main.getDBS().clearSolvedReportsTable();
               } else {
                  Main.getSolvedReportsLog().clearSolvedReports();
               }

               var3.sendMessage("");
               var3.sendMessage("§eAll solved reports have been removed.");
               var3.sendMessage("");
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cNo")) {
               Main.getGui().createSolvedReportsGui(var3);
            }

            var1.setCancelled(true);
         }
      } catch (Exception var4) {
         ;
      }

   }

   @EventHandler
   public void onConfirmGuiClick3(InventoryClickEvent var1) {
      try {
         if(var1.getClickedInventory() != null) {
            if(var1.getCurrentItem() == null) {
               return;
            }

            Inventory var2 = var1.getClickedInventory();
            Player var3 = (Player)var1.getWhoClicked();
            if(!var2.getTitle().equalsIgnoreCase("§cAre you sure?  ")) {
               return;
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aYes")) {
               if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
                  Main.getDBS().clearGlobalReportsTable();
               } else {
                  Main.getReportsLog().clearReports();
               }

               var3.sendMessage("");
               var3.sendMessage("§eAll global reports have been removed.");
               var3.sendMessage("");
               var3.closeInventory();
            }

            if(var1.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cNo")) {
               Main.getGui().createGlobalReportsList(var3);
            }

            var1.setCancelled(true);
         }
      } catch (Exception var4) {
         ;
      }

   }
}
