package me.soul.report.events;

import me.soul.report.utils.Logger;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {

   @EventHandler
   public void onJoin(PlayerJoinEvent var1) {
      Player var2 = var1.getPlayer();
      if(var2.hasPermission("reportsystem.join_alert")) {
         Logger.log(var2, "join_alert");
      }

   }
}
