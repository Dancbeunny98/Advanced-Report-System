package me.soul.report.events;

import me.soul.report.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class LeftListener implements Listener {

   @EventHandler
   public void onLeft(PlayerQuitEvent var1) {
      Player var2 = var1.getPlayer();
      if(Main.getStatus().hasReview(var2.getName())) {
         Main.getStatus().removeReviewBy(var2.getName());
      }

   }
}
