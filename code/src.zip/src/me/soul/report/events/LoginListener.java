package me.soul.report.events;

import me.soul.report.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public class LoginListener implements Listener {

   @EventHandler
   public void onJoin(PlayerLoginEvent var1) {
      Player var2 = var1.getPlayer();
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql") && Main.getDBS().playerExists(var2.getUniqueId())) {
         Main.getDBS().setServer(var2.getUniqueId(), Main.getInstance().getConfig().getString("Server"));
      }

   }
}
