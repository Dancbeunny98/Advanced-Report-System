package me.soul.report.events;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Iterator;
import me.soul.report.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class PluginListener implements PluginMessageListener {

   public void onPluginMessageReceived(String var1, Player var2, byte[] var3) {
      if(var1.equalsIgnoreCase("ReportSystem")) {
         ByteArrayDataInput var4 = ByteStreams.newDataInput(var3);
         String var5 = "";
         short var6 = var4.readShort();
         byte[] var7 = new byte[var6];
         var4.readFully(var7);
         DataInputStream var8 = new DataInputStream(new ByteArrayInputStream(var7));

         try {
            var5 = var8.readUTF();
         } catch (IOException var12) {
            var12.printStackTrace();
         }

         String[] var9;
         Player var10;
         Iterator var11;
         if(var5.startsWith("sr")) {
            var9 = var5.split(" ");
            var11 = Bukkit.getOnlinePlayers().iterator();

            while(var11.hasNext()) {
               var10 = (Player)var11.next();
               if(var10.hasPermission("reportsystem.admin")) {
                  Logger.adminLog("report", var10, Bukkit.getPlayer(var9[1]), Bukkit.getPlayer(var9[2]), var9[4], var9[3].replace("_", " "));
               }
            }
         }

         if(var5.startsWith("c")) {
            var9 = var5.split(" ");
            var11 = Bukkit.getOnlinePlayers().iterator();

            while(var11.hasNext()) {
               var10 = (Player)var11.next();
               if(var10.hasPermission("reportsystem.admin")) {
                  Logger.adminLog("close_report", var10, Bukkit.getPlayer(var9[1]), Bukkit.getPlayer(var9[2]), var9[4], var9[3].replace("_", " "));
               }
            }
         }
      }

   }
}
