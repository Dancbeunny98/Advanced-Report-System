package me.soul.report.files;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class Languages {

   FileConfiguration l;
   File lf;
   boolean created;


   public void setUp(Plugin var1) {
      if(!var1.getDataFolder().exists()) {
         var1.getDataFolder().mkdir();
      }

      this.created = false;
      this.lf = new File(var1.getDataFolder(), "languages.yml");
      if(!this.lf.exists()) {
         try {
            this.lf.createNewFile();
            this.created = true;
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      this.l = YamlConfiguration.loadConfiguration(this.lf);
      if(this.created) {
         this.defaultMessages();
         this.created = false;
      }

   }

   public void saveLanguages() {
      try {
         this.l.save(this.lf);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public void reloadLanguages() {
      this.l = YamlConfiguration.loadConfiguration(this.lf);
   }

   public FileConfiguration getLanguages() {
      return this.l;
   }

   public void defaultMessages() {
      this.getLanguages().set("prefix", "&c&lReport&8:&7 ");
      this.getLanguages().set("only_players", "&cOnly players can do this action");
      this.getLanguages().set("cooldown", "&cYou need to wait 2 minutes to report another player.");
      this.getLanguages().set("please", "&2Please use:");
      this.getLanguages().set("reporttype1", "&a/report <&2player&a>");
      this.getLanguages().set("reporttype2", "&a/report <&2player&a> [&2reason&a]");
      this.getLanguages().set("unknown_player", "&cThis player is currently offline or doesnt exist");
      this.getLanguages().set("short_reason", "&cSelected reason is too short");
      this.getLanguages().set("long_reason", "&cSelected reason is too long");
      this.getLanguages().set("symbols", "&cReason cannot contains symbols");
      this.getLanguages().set("permission", "&cYou dont have enough permissions");
      this.getLanguages().set("report_sended", "&aYour report has been successfully send");
      this.getLanguages().set("report", "&7[&4%server%&7] &4%player% &creported &4%target% &cfor &4%reason%");
      this.getLanguages().set("close_report", "&7[&2%server%&7] &2%player% &aclosed &2%target%\'s&a report for &2%reason%");
      this.getLanguages().set("no_review", "&eYou dont have any reviewed player.");
      this.getLanguages().set("reason_other", "&7Specify the report reason in chat");
      this.getLanguages().set("join_alert", "&7There are &c%n%&7 unresolved reports");
      this.getLanguages().set("ReportGui.Killaura.item", "DIAMOND_SWORD");
      this.getLanguages().set("ReportGui.Killaura.name", "&cKillaura");
      this.getLanguages().set("ReportGui.Killaura.slot", Integer.valueOf(9));
      ArrayList var1 = new ArrayList();
      var1.add("");
      var1.add("&7- Killaura = Hacked Client(s) module which automatically");
      var1.add("&7hit entities (Players, Mobs).");
      var1.add("&7Often can hit through walls.");
      var1.add("");
      this.getLanguages().set("ReportGui.Killaura.lore", var1);
      this.getLanguages().set("ReportGui.Aimbot.item", "ARROW");
      this.getLanguages().set("ReportGui.Aimbot.name", "&cAimbot");
      this.getLanguages().set("ReportGui.Aimbot.slot", Integer.valueOf(10));
      ArrayList var2 = new ArrayList();
      var2.add("");
      var2.add("&7- Aimbot = Hacked Client(s) module which automatically");
      var2.add("&7face to other entities (Players, Mobs).");
      var2.add("");
      this.getLanguages().set("ReportGui.Aimbot.lore", var2);
      this.getLanguages().set("ReportGui.AntiKnockback.item", "DIAMOND_CHESTPLATE");
      this.getLanguages().set("ReportGui.AntiKnockback.name", "&cAntiKnockback");
      this.getLanguages().set("ReportGui.AntiKnockback.slot", Integer.valueOf(11));
      ArrayList var3 = new ArrayList();
      var3.add("");
      var3.add("&7- AntiKnockback = Reduce or clear");
      var3.add("&7the player knockback effect.");
      var3.add("");
      this.getLanguages().set("ReportGui.AntiKnockback.lore", var3);
      this.getLanguages().set("ReportGui.Speed.item", "FEATHER");
      this.getLanguages().set("ReportGui.Speed.name", "&cSpeed");
      this.getLanguages().set("ReportGui.Speed.slot", Integer.valueOf(12));
      ArrayList var4 = new ArrayList();
      var4.add("");
      var4.add("&7- Speed = Increase the player speed");
      var4.add("&7without any potion effect.");
      var4.add("");
      this.getLanguages().set("ReportGui.Speed.lore", var4);
      this.getLanguages().set("ReportGui.Scaffold.item", "WOOD_STEP");
      this.getLanguages().set("ReportGui.Scaffold.name", "&cScaffold");
      this.getLanguages().set("ReportGui.Scaffold.slot", Integer.valueOf(13));
      ArrayList var5 = new ArrayList();
      var5.add("");
      var5.add("&7- Scaffold = Automatically place blocks");
      var5.add("&7under the player.");
      var5.add("&7Often used in bedwars/skywars.");
      var5.add("");
      this.getLanguages().set("ReportGui.Scaffold.lore", var5);
      this.getLanguages().set("ReportGui.WallHack.item", "IRON_PICKAXE");
      this.getLanguages().set("ReportGui.WallHack.name", "&cWallHack");
      this.getLanguages().set("ReportGui.WallHack.slot", Integer.valueOf(14));
      ArrayList var6 = new ArrayList();
      var6.add("");
      var6.add("&7- WallHack = Used to see other players through blocks");
      var6.add("&7- XRay = Used to see all minerals");
      var6.add("");
      this.getLanguages().set("ReportGui.WallHack.lore", var6);
      this.getLanguages().set("ReportGui.Phase.item", "FENCE_GATE");
      this.getLanguages().set("ReportGui.Phase.name", "&cPhase");
      this.getLanguages().set("ReportGui.Phase.slot", Integer.valueOf(15));
      ArrayList var7 = new ArrayList();
      var7.add("");
      var7.add("&7- Phase = Used to get pass through semi-blocks");
      var7.add("&7trapdoors, doors.");
      var7.add("");
      this.getLanguages().set("ReportGui.Phase.lore", var7);
      this.getLanguages().set("ReportGui.BugAbuse.item", "SLIME_BALL");
      this.getLanguages().set("ReportGui.BugAbuse.name", "&cBug Abuse");
      this.getLanguages().set("ReportGui.BugAbuse.slot", Integer.valueOf(16));
      ArrayList var8 = new ArrayList();
      var8.add("");
      var8.add("&7- Bug Abuse = Abuse of some Minecraft bugs");
      var8.add("&7to get unfair advantages.");
      var8.add("");
      this.getLanguages().set("ReportGui.BugAbuse.lore", var8);
      this.getLanguages().set("ReportGui.Other.item", "NETHER_STAR");
      this.getLanguages().set("ReportGui.Other.name", "&cOther");
      this.getLanguages().set("ReportGui.Other.slot", Integer.valueOf(17));
      ArrayList var9 = new ArrayList();
      var9.add("");
      var9.add("&7 Did not found the report reason before?");
      var9.add("&7 Left click this and specify an other reason");
      var9.add("");
      this.getLanguages().set("ReportGui.Other.lore", var9);
      this.saveLanguages();
   }
}
