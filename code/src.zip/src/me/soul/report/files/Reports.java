package me.soul.report.files;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.soul.report.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class Reports {

   FileConfiguration r;
   File rf;


   public void setUp(Plugin var1) {
      if(!var1.getDataFolder().exists()) {
         var1.getDataFolder().mkdir();
      }

      this.rf = new File(var1.getDataFolder(), "reportslog.yml");
      if(!this.rf.exists()) {
         try {
            this.rf.createNewFile();
         } catch (IOException var3) {
            ;
         }
      }

      this.r = YamlConfiguration.loadConfiguration(this.rf);
   }

   public void saveReportsLog() {
      try {
         this.r.save(this.rf);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public void reloadReportsLog() {
      this.r = YamlConfiguration.loadConfiguration(this.rf);
   }

   public FileConfiguration getReportsLog() {
      return this.r;
   }

   public List getReports() {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var1 = this.getReportsLog().getStringList("Reports");
         return var1;
      } else {
         return Main.getDBS().getGlobalReports();
      }
   }

   public void addReport(Player var1, String var2, String var3) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var4 = this.getReportsLog().getStringList("Reports");
         var4.add(var1.getName() + ":" + var2.replace(" ", "_"));
         this.getReportsLog().set("Reports", var4);
         this.saveReportsLog();
      } else {
         Main.getDBS().addReport(var1.getUniqueId(), var2, var3);
      }

   }

   public List getReportReasons(Player var1) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         ArrayList var2 = new ArrayList();

         for(int var3 = 0; var3 < this.getReportsLog().getStringList("Reports").size(); ++var3) {
            String[] var4 = ((String)this.getReportsLog().getStringList("Reports").get(var3)).split(":");
            if(var4[0].equalsIgnoreCase(var1.getName())) {
               var2.add(var4[1]);
            }
         }

         return var2;
      } else {
         return Main.getDBS().getReasons(var1.getUniqueId());
      }
   }

   public int getSameReasonsNumber(Player var1, String var2) {
      int var3 = 0;

      for(int var4 = 0; var4 < this.getReportReasons(var1).size(); ++var4) {
         if(((String)this.getReportReasons(var1).get(var4)).equalsIgnoreCase(var2)) {
            ++var3;
         }
      }

      if(var3 <= 0) {
         var3 = 1;
      }

      return var3;
   }

   public void removeReport(String var1) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var2 = this.getReports();
         Iterator var4 = this.getReports().iterator();

         while(var4.hasNext()) {
            String var3 = (String)var4.next();
            String[] var5 = var3.split(":");
            if(var5[0].equalsIgnoreCase(var1)) {
               var2.remove(var3);
            }
         }

         this.getReportsLog().set("Reports", var2);
         this.saveReportsLog();
      } else {
         Main.getDBS().removeReport(Bukkit.getPlayer(var1).getUniqueId());
      }

   }

   public void clearReports() {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var1 = this.getReportsLog().getStringList("Reports");
         var1.clear();
         this.getReportsLog().set("Reports", var1);
         this.saveReportsLog();
      } else {
         Main.getDBS().clearLocalReportsTable();
      }

   }
}
