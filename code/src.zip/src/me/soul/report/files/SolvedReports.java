package me.soul.report.files;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import me.soul.report.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class SolvedReports {

   FileConfiguration sr;
   File srf;


   public void setUp(Plugin var1) {
      if(!var1.getDataFolder().exists()) {
         var1.getDataFolder().mkdir();
      }

      this.srf = new File(var1.getDataFolder(), "solvedreportslog.yml");
      if(!this.srf.exists()) {
         try {
            this.srf.createNewFile();
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      this.sr = YamlConfiguration.loadConfiguration(this.srf);
   }

   public void saveSolvedReportsLog() {
      try {
         this.sr.save(this.srf);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public void reloadSolvedReportsLog() {
      this.sr = YamlConfiguration.loadConfiguration(this.srf);
   }

   public FileConfiguration getSolvedReportsLog() {
      return this.sr;
   }

   public List getSolvedReports() {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var11 = this.getSolvedReportsLog().getStringList("SolvedReports");
         return var11;
      } else {
         ArrayList var1 = new ArrayList();
         Iterator var3 = Main.getDBS().getSolvedReports().iterator();

         while(var3.hasNext()) {
            UUID var2 = (UUID)var3.next();
            var1.add(var2.toString());
         }

         return var1;
      }
   }

   public void addSolvedReport(String var1, String var2) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var3 = this.getSolvedReports();
         var3.add(var1 + ":" + var2.replace(" ", "_"));
         this.getSolvedReportsLog().set("SolvedReports", var3);
         this.saveSolvedReportsLog();
      } else {
         Main.getDBS().addSolvedReport(Bukkit.getPlayer(var1).getUniqueId(), var1, var2);
      }

   }

   public List getStaffers() {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().getStaffers();
      } else {
         ArrayList var1 = new ArrayList();

         for(int var2 = 0; var2 < this.getSolvedReports().size(); ++var2) {
            String[] var3 = ((String)this.getSolvedReports().get(var2)).split(":");
            var1.add(var3[0]);
         }

         return var1;
      }
   }

   public List getReasons() {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().getComments();
      } else {
         ArrayList var1 = new ArrayList();

         for(int var2 = 0; var2 < this.getSolvedReports().size(); ++var2) {
            String[] var3 = ((String)this.getSolvedReports().get(var2)).split(":");
            var1.add(var3[1]);
         }

         return var1;
      }
   }

   public int getSolvedReportsOf(String var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < this.getSolvedReports().size(); ++var3) {
         String[] var4 = ((String)this.getSolvedReports().get(var3)).split(":");
         if(var4[0].equalsIgnoreCase(var1)) {
            ++var2;
         }
      }

      if(var2 < 1) {
         var2 = 1;
      }

      return var2;
   }

   public void clearSolvedReports() {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var1 = this.getSolvedReportsLog().getStringList("SolvedReports");
         var1.clear();
         this.getSolvedReportsLog().set("SolvedReports", var1);
         this.saveSolvedReportsLog();
      } else {
         Main.getDBS().clearSolvedReportsTable();
      }

   }
}
