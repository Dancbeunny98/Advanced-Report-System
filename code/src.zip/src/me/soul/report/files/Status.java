package me.soul.report.files;

import java.io.File;
import java.io.IOException;
import java.util.List;
import me.soul.report.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class Status {

   FileConfiguration s;
   File sf;


   public void setUp(Plugin var1) {
      if(!var1.getDataFolder().exists()) {
         var1.getDataFolder().mkdir();
      }

      this.sf = new File(var1.getDataFolder(), "statuslog.yml");
      if(!this.sf.exists()) {
         try {
            this.sf.createNewFile();
         } catch (IOException var3) {
            var3.printStackTrace();
         }
      }

      this.s = YamlConfiguration.loadConfiguration(this.sf);
   }

   public void saveStatusLog() {
      try {
         this.s.save(this.sf);
      } catch (IOException var2) {
         var2.printStackTrace();
      }

   }

   public void reloadStatussLog() {
      this.s = YamlConfiguration.loadConfiguration(this.sf);
   }

   public FileConfiguration getStatusLog() {
      return this.s;
   }

   public List getStatus() {
      return this.getStatusLog().getStringList("Status");
   }

   public void setReviewed(String var1, String var2) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var3 = this.getStatus();
         var3.add(var1 + ":" + var2);
         this.getStatusLog().set("Status", var3);
         this.saveStatusLog();
      } else {
         Main.getDBS().setStatus(Bukkit.getPlayer(var1).getUniqueId(), var2);
      }

   }

   public void removeReview(String var1) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var2 = this.getStatus();

         for(int var3 = 0; var3 < var2.size(); ++var3) {
            String[] var4 = ((String)var2.get(var3)).split(":");
            if(var4[0].equalsIgnoreCase(var1)) {
               var2.remove(var3);
            }
         }

         this.getStatusLog().set("Status", var2);
         this.saveStatusLog();
      } else {
         Main.getDBS().removeStatus(Bukkit.getPlayer(var1).getUniqueId());
      }

   }

   public void removeReviewBy(String var1) {
      if(!Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         List var2 = this.getStatus();

         for(int var3 = 0; var3 < var2.size(); ++var3) {
            String[] var4 = ((String)var2.get(var3)).split(":");
            if(var4[1].equalsIgnoreCase(var1)) {
               var2.remove(var3);
            }
         }

         this.getStatusLog().set("Status", var2);
         this.saveStatusLog();
      } else {
         Main.getDBS().removeStatus(Bukkit.getPlayer(var1).getUniqueId());
      }

   }

   public boolean isOpen(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().isOpen(Bukkit.getPlayer(var1).getUniqueId());
      } else {
         for(int var2 = 0; var2 < this.getStatus().size(); ++var2) {
            String[] var3 = ((String)this.getStatus().get(var2)).split(":");
            if(var3[0].equalsIgnoreCase(var1)) {
               return false;
            }
         }

         return true;
      }
   }

   public boolean hasReview(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().hasReview(var1);
      } else {
         for(int var2 = 0; var2 < this.getStatus().size(); ++var2) {
            String[] var3 = ((String)this.getStatus().get(var2)).split(":");
            if(var3[1].equalsIgnoreCase(var1)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean isReviewed(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().isReviewed(Bukkit.getPlayer(var1).getUniqueId());
      } else {
         for(int var2 = 0; var2 < this.getStatus().size(); ++var2) {
            String[] var3 = ((String)this.getStatus().get(var2)).split(":");
            if(var3[0].equalsIgnoreCase(var1)) {
               return true;
            }
         }

         return false;
      }
   }

   public String getStaffer(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().getReviewer(Bukkit.getPlayer(var1).getUniqueId());
      } else {
         for(int var2 = 0; var2 < this.getStatus().size(); ++var2) {
            String[] var3 = ((String)this.getStatus().get(var2)).split(":");
            if(var3[0].equalsIgnoreCase(var1)) {
               return var3[1];
            }
         }

         return "failed";
      }
   }

   public String getTarget(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         return Main.getDBS().getTarget(var1);
      } else {
         for(int var2 = 0; var2 < this.getStatus().size(); ++var2) {
            String[] var3 = ((String)this.getStatus().get(var2)).split(":");
            if(var3[1].equalsIgnoreCase(var1)) {
               return var3[0];
            }
         }

         return "failed";
      }
   }
}
