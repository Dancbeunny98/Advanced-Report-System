package me.soul.report.utils;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.soul.report.Main;

public class DBS {

   public void setStatus(UUID var1, String var2) {
      Main.getSql().update("INSERT INTO FearStatus (UUID, Staffer) VALUES (\'" + var1 + "\', \'" + var2 + "\');");
   }

   public boolean isReviewed(UUID var1) {
      ResultSet var2 = getResult("SELECT * FROM FearStatus WHERE UUID=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            try {
               if(var2.getString("UUID") != null) {
                  return true;
               }

               return false;
            } catch (SQLException var4) {
               var4.printStackTrace();
            }
         }
      } catch (SQLException var5) {
         var5.printStackTrace();
      }

      return false;
   }

   public boolean hasReview(String var1) {
      ResultSet var2 = getResult("SELECT UUID FROM FearStatus WHERE Staffer=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            if(var2.getString("UUID") != null) {
               return true;
            }

            return false;
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return false;
   }

   public String getReviewer(UUID var1) {
      ResultSet var2 = getResult("SELECT Staffer FROM FearStatus WHERE UUID=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            return var2.getString("Staffer");
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return "failed";
   }

   public String getTarget(String var1) {
      ResultSet var2 = getResult("SELECT UUID FROM FearStatus WHERE Staffer=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            return var2.getString("UUID");
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return "failed";
   }

   public void removeStatus(UUID var1) {
      ResultSet var2 = getResult("SELECT * FROM FearStatus WHERE UUID=\'" + var1 + "\';");

      try {
         while(var2.next()) {
            if(var2.getString("UUID") != null) {
               Main.getSql().update("DELETE FROM FearStatus WHERE UUID =\'" + var1 + "\';");
            }
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

   }

   public boolean isOpen(UUID var1) {
      ResultSet var2 = getResult("SELECT * FROM FearStatus WHERE UUID=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            if(var2.getString("UUID") != null) {
               return true;
            }

            return false;
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return false;
   }

   public void addReport(UUID var1, String var2, String var3) {
      Main.getSql().update("INSERT INTO FearReports (UUID, Reason, Server) VALUES (\'" + var1 + "\', \'" + var2 + "\', \'" + var3 + "\');");
   }

   public void removeReport(UUID var1) {
      ResultSet var2 = getResult("SELECT * FROM FearReports WHERE UUID=\'" + var1 + "\';");

      try {
         while(var2.next()) {
            if(var2.getString("UUID") != null) {
               Main.getSql().update("DELETE FROM FearReports WHERE UUID =\'" + var1 + "\';");
            }
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

   }

   public static ResultSet getResult(String var0) {
      ResultSet var1 = null;

      try {
         Statement var3 = Main.getSql().getCo().createStatement();
         var1 = var3.executeQuery(var0);
      } catch (SQLException var31) {
         System.err.println(var31);
      }

      return var1;
   }

   public boolean playerExists(UUID var1) {
      try {
         ResultSet var3 = getResult("SELECT * FROM FearReports WHERE UUID=\'" + var1 + "\';");
         return var3.next()?var3.getString("UUID") != null:false;
      } catch (SQLException var31) {
         var31.printStackTrace();
         return false;
      }
   }

   public void setServer(UUID var1, String var2) {
      Main.getSql().update("UPDATE FearReports SET Server=\'" + var2 + "\' WHERE UUID=\'" + var1 + "\';");
   }

   public List getReportsOf(String var1) {
      ArrayList var2 = new ArrayList();
      ResultSet var3 = getResult("SELECT * FROM FearReports WHERE UUID=\'" + var1 + "\';");

      try {
         while(var3.next()) {
            var2.add(var3.getString("*"));
         }
      } catch (SQLException var5) {
         var5.printStackTrace();
      }

      return var2;
   }

   public List getReasons(UUID var1) {
      ArrayList var2 = new ArrayList();

      try {
         ResultSet var4 = getResult("SELECT Reason FROM FearReports WHERE UUID=\'" + var1 + "\';");

         while(var4.next()) {
            var2.add(var4.getString("Reason"));
         }
      } catch (SQLException var41) {
         var41.printStackTrace();
      }

      return var2;
   }

   public int getSameReasonsNumber(UUID var1, String var2) {
      int var3 = 0;
      ResultSet var4 = getResult("SELECT Reason FROM FearReports WHERE UUID=\'" + var1 + "\';");

      try {
         while(var4.next()) {
            if(var4.getString("Reason").equalsIgnoreCase(var2)) {
               ++var3;
            }
         }
      } catch (SQLException var6) {
         var6.printStackTrace();
      }

      if(var3 <= 0) {
         var3 = 1;
      }

      return var3;
   }

   public String getServer(UUID var1) {
      ResultSet var2 = getResult("SELECT Server FROM FearReports WHERE UUID=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            return var2.getString("Server");
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return "failed";
   }

   public int getTotalReports() throws SQLException {
      PreparedStatement var1 = Main.getSql().getCo().prepareStatement("SELECT COUNT(*) FROM FearReports");
      ResultSet var2 = var1.executeQuery();
      int var3 = var2.getInt(1);
      return var3;
   }

   public List getReports() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT UUID FROM FearReports;");

      try {
         while(var2.next()) {
            var1.add(var2.getString("UUID"));
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public List getSolvedReports() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT UUID FROM FearSolvedReports;");

      try {
         while(var2.next()) {
            var1.add(UUID.fromString(var2.getString("UUID")));
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public List getStaffers() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT Staffer FROM FearSolvedReports;");

      try {
         while(var2.next()) {
            var1.add(var2.getString("Staffer"));
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public List getComments() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT Comment FROM FearSolvedReports;");

      try {
         while(var2.next()) {
            var1.add(var2.getString("Comment"));
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public void clearGlobalReportsTable() {
      Main.getSql().update("TRUNCATE FearReports");
      Main.getSql().update("DELETE FROM FearReports");
   }

   public void clearLocalReportsTable() {
      ResultSet var1 = getResult("SELECT * FROM FearReports WHERE Server=\'" + Main.getInstance().getConfig().getString("Server") + "\';");

      try {
         while(var1.next()) {
            Main.getSql().update("DELETE FROM FearReports WHERE Server=\'" + Main.getInstance().getConfig().getString("Server") + "\';");
         }
      } catch (SQLException var3) {
         var3.printStackTrace();
      }

   }

   public List getLocalReports() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT UUID FROM FearReports WHERE Server=\'" + Main.getInstance().getConfig().getString("Server") + "\';");

      try {
         while(var2.next()) {
            if(!var1.contains(var2.getString("UUID"))) {
               var1.add(var2.getString("UUID"));
            }
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public List getGlobalReports() {
      ArrayList var1 = new ArrayList();
      ResultSet var2 = getResult("SELECT UUID FROM FearReports;");

      try {
         while(var2.next()) {
            if(!var1.contains(var2.getString("UUID"))) {
               var1.add(var2.getString("UUID"));
            }
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return var1;
   }

   public int getTotalSolvedReports() throws SQLException {
      PreparedStatement var1 = Main.getSql().getCo().prepareStatement("SELECT COUNT(*) FROM FearSolvedReports");
      ResultSet var2 = var1.executeQuery();
      int var3 = var2.getInt(1);
      return var3;
   }

   public void addSolvedReport(UUID var1, String var2, String var3) {
      Main.getSql().update("INSERT INTO FearSolvedReports (UUID, Staffer, comment) VALUES (\'" + var1 + "\', \'" + var2 + "\', \'" + var3 + "\');");
   }

   public void removeSolvedReport(UUID var1) {
      ResultSet var2 = getResult("SELECT * FROM FearSolvedReports WHERE UUID=\'" + var1 + "\';");

      try {
         while(var2.next()) {
            if(var2.getString("UUID") != null) {
               Main.getSql().update("DELETE FROM FearSolvedReports WHERE UUID =\'" + var1 + "\';");
            }
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

   }

   public void clearSolvedReportsTable() {
      Main.getSql().update("TRUNCATE FearSolvedReports");
      Main.getSql().update("DELETE FROM FearSolvedReports");
   }

   public boolean isOnline(UUID var1) {
      ResultSet var2 = getResult("SELECT Server FROM FearReports WHERE UUID=\'" + var1 + "\';");

      try {
         if(var2.next()) {
            return !var2.getString("Server").equalsIgnoreCase("Offline");
         }
      } catch (SQLException var4) {
         var4.printStackTrace();
      }

      return false;
   }

   public int getSolvedReportsOf(UUID var1) {
      ArrayList var2 = new ArrayList();
      ResultSet var3 = getResult("SELECT * FROM FearSolvedReports WHERE UUID=\'" + var1 + "\';");

      try {
         while(var3.next()) {
            var2.add(var3.getString("UUID"));
         }
      } catch (SQLException var5) {
         var5.printStackTrace();
      }

      return var2.size();
   }

   public void disableServers() {
      Main.getSql().update("UPDATE FearReports SET Server=\'Offline\';");
   }
}
