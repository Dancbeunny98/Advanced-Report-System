package me.soul.report.utils;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import me.soul.report.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class Gui {

   public HashMap pages = new HashMap();
   public HashMap pages2 = new HashMap();
   public HashMap pages3 = new HashMap();


   public void createReportGui(Player var1, Player var2) {
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 27, "§cReport " + var2.getName());
      ItemStack var4 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var5 = var4.getItemMeta();
      var4.setDurability((short)15);
      var5.setDisplayName(" ");
      var5.setLore(Arrays.asList(new String[]{" "}));
      var4.setItemMeta(var5);

      for(int var34 = 0; var34 < var3.getSize(); ++var34) {
         var3.setItem(var34, var4);
      }

      ItemStack var341 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Killaura.item")));
      ItemMeta var7 = var341.getItemMeta();
      var7.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Killaura.name").replace("&", "§"));
      ArrayList var8 = new ArrayList();

      for(int var35 = 0; var35 < Main.getLanguages().getLanguages().getStringList("ReportGui.Killaura.lore").size(); ++var35) {
         var8.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Killaura.lore").get(var35)).replace("&", "§"));
      }

      var7.setLore(var8);
      var341.setItemMeta(var7);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Killaura.slot"), var341);
      ItemStack var351 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Aimbot.item")));
      ItemMeta var10 = var351.getItemMeta();
      var10.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Aimbot.name").replace("&", "§"));
      ArrayList var11 = new ArrayList();

      for(int var36 = 0; var36 < Main.getLanguages().getLanguages().getStringList("ReportGui.Aimbot.lore").size(); ++var36) {
         var11.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Aimbot.lore").get(var36)).replace("&", "§"));
      }

      var10.setLore(var11);
      var351.setItemMeta(var10);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Aimbot.slot"), var351);
      ItemStack var361 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.AntiKnockback.item")));
      ItemMeta var13 = var361.getItemMeta();
      var13.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.AntiKnockback.name").replace("&", "§"));
      ArrayList var14 = new ArrayList();

      for(int var37 = 0; var37 < Main.getLanguages().getLanguages().getStringList("ReportGui.AntiKnockback.lore").size(); ++var37) {
         var14.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.AntiKnockback.lore").get(var37)).replace("&", "§"));
      }

      var13.setLore(var14);
      var361.setItemMeta(var13);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.AntiKnockback.slot"), var361);
      ItemStack var371 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Speed.item")));
      ItemMeta var16 = var371.getItemMeta();
      var16.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Speed.name").replace("&", "§"));
      ArrayList var17 = new ArrayList();

      for(int var38 = 0; var38 < Main.getLanguages().getLanguages().getStringList("ReportGui.Speed.lore").size(); ++var38) {
         var17.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Speed.lore").get(var38)).replace("&", "§"));
      }

      var16.setLore(var17);
      var371.setItemMeta(var16);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Speed.slot"), var371);
      ItemStack var381 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Scaffold.item")));
      ItemMeta var19 = var381.getItemMeta();
      var19.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Scaffold.name").replace("&", "§"));
      ArrayList var20 = new ArrayList();

      for(int var39 = 0; var39 < Main.getLanguages().getLanguages().getStringList("ReportGui.Scaffold.lore").size(); ++var39) {
         var20.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Scaffold.lore").get(var39)).replace("&", "§"));
      }

      var19.setLore(var20);
      var381.setItemMeta(var19);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Scaffold.slot"), var381);
      ItemStack var391 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.WallHack.item")));
      ItemMeta var22 = var391.getItemMeta();
      var22.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.WallHack.name").replace("&", "§"));
      ArrayList var23 = new ArrayList();

      for(int var40 = 0; var40 < Main.getLanguages().getLanguages().getStringList("ReportGui.WallHack.lore").size(); ++var40) {
         var23.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.WallHack.lore").get(var40)).replace("&", "§"));
      }

      var22.setLore(var23);
      var391.setItemMeta(var22);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.WallHack.slot"), var391);
      ItemStack var401 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Phase.item")));
      ItemMeta var25 = var401.getItemMeta();
      var25.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Phase.name").replace("&", "§"));
      ArrayList var26 = new ArrayList();

      for(int var41 = 0; var41 < Main.getLanguages().getLanguages().getStringList("ReportGui.Phase.lore").size(); ++var41) {
         var26.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Phase.lore").get(var41)).replace("&", "§"));
      }

      var25.setLore(var26);
      var401.setItemMeta(var25);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Phase.slot"), var401);
      ItemStack var411 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.BugAbuse.item")));
      ItemMeta var28 = var411.getItemMeta();
      var28.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.BugAbuse.name").replace("&", "§"));
      ArrayList var29 = new ArrayList();

      for(int var42 = 0; var42 < Main.getLanguages().getLanguages().getStringList("ReportGui.BugAbuse.lore").size(); ++var42) {
         var29.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.BugAbuse.lore").get(var42)).replace("&", "§"));
      }

      var28.setLore(var29);
      var411.setItemMeta(var28);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.BugAbuse.slot"), var411);
      ItemStack var421 = new ItemStack(Material.getMaterial(Main.getLanguages().getLanguages().getString("ReportGui.Other.item")));
      ItemMeta var31 = var421.getItemMeta();
      var31.setDisplayName(Main.getLanguages().getLanguages().getString("ReportGui.Other.name").replace("&", "§"));
      ArrayList var32 = new ArrayList();

      for(int var33 = 0; var33 < Main.getLanguages().getLanguages().getStringList("ReportGui.Other.lore").size(); ++var33) {
         var32.add(((String)Main.getLanguages().getLanguages().getStringList("ReportGui.Other.lore").get(var33)).replace("&", "§"));
      }

      var31.setLore(var32);
      var421.setItemMeta(var31);
      var3.setItem(Main.getLanguages().getLanguages().getInt("ReportGui.Other.slot"), var421);
      var1.openInventory(var3);
   }

   public void createStaffGui(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, "§cStaff Gui");
      ItemStack var3 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var4 = var3.getItemMeta();
      var3.setDurability((short)15);
      var4.setDisplayName(" ");
      var4.setLore(Arrays.asList(new String[]{" "}));
      var3.setItemMeta(var4);

      for(int var6 = 0; var6 < var2.getSize(); ++var6) {
         var2.setItem(var6, var3);
      }

      ItemStack var7;
      ItemMeta var8;
      ItemStack var11;
      ItemMeta var111;
      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         var11 = new ItemStack(Material.DIAMOND_BLOCK);
         var111 = var11.getItemMeta();
         var111.setDisplayName("§eGlobal reports");
         var111.setLore(Arrays.asList(new String[]{"", "§fAll reports", "", "§7All reports in every server", ""}));
         var11.setItemMeta(var111);
         var2.setItem(11, var11);
         var7 = new ItemStack(Material.REDSTONE_BLOCK);
         var8 = var7.getItemMeta();
         var8.setDisplayName("§eLocal reports");
         var8.setLore(Arrays.asList(new String[]{"", "§fPer server reports", "", "§7Reports in this server", ""}));
         var7.setItemMeta(var8);
         var2.setItem(13, var7);
         ItemStack var9 = new ItemStack(Material.EMERALD_BLOCK);
         ItemMeta var10 = var9.getItemMeta();
         var10.setDisplayName("§eSolved reports");
         var10.setLore(Arrays.asList(new String[]{"", "§fSee all solved reports", ""}));
         var9.setItemMeta(var10);
         var2.setItem(15, var9);
      } else {
         var11 = new ItemStack(Material.DIAMOND_BLOCK);
         var111 = var11.getItemMeta();
         var111.setDisplayName("§eReports");
         var111.setLore(Arrays.asList(new String[]{"", "§fAll reports", "", "§7List of every report", ""}));
         var11.setItemMeta(var111);
         var2.setItem(11, var11);
         var7 = new ItemStack(Material.EMERALD_BLOCK);
         var8 = var7.getItemMeta();
         var8.setDisplayName("§eSolved reports");
         var8.setLore(Arrays.asList(new String[]{"", "§fSee all solved reports", ""}));
         var7.setItemMeta(var8);
         var2.setItem(15, var7);
      }

      var1.openInventory(var2);
   }

   public void createLocalReportsListGui(Player var1) {
      int var2 = ((Integer)this.pages.get(var1)).intValue();
      boolean var3 = true;
      ArrayList var4 = new ArrayList();

      for(int var17 = 0; var17 < Main.getDBS().getLocalReports().size(); ++var17) {
         UUID var18 = UUID.fromString((String)Main.getDBS().getLocalReports().get(var17));
         String var19 = Bukkit.getPlayer(var18).getName();
         ItemStack var22;
         String var23;
         ArrayList var25;
         int var26;
         if(Main.getStatus().isOpen(Bukkit.getPlayer(var19).getUniqueId())) {
            var22 = new ItemStack(Material.PLAYER_HEAD, 1, (short)3);
            SkullMeta var24 = (SkullMeta)var22.getItemMeta();
            var23 = "";
            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 3) {
               var23 = "§a";
            }

            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() > 3 && Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 8) {
               var23 = "§e";
            }

            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() >= 10) {
               var23 = "§c";
            }

            var24.setDisplayName("§e" + Bukkit.getPlayer(var19).getName() + " " + var23 + "° " + "§7(§c" + Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() + "§7)");
            var25 = new ArrayList();
            var25.add("");
            var25.add("§aReasons: ");
            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 5 && Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() != 1) {
               for(var26 = 0; var26 < Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size(); ++var26) {
                  if(!var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)")) {
                     var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)");
                  }
               }
            } else {
               if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() > 5) {
                  for(var26 = 0; var26 < Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size(); ++var26) {
                     if(!var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)")) {
                        var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)");
                     }
                  }

                  var25.add("§f...");
               }

               if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() == 1 && !var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " "))) {
                  var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " ")) + "§7)");
               }
            }

            var25.add("");
            var25.add("§aStatus: §fOpen");
            var25.add("");
            var24.setLore(var25);
            var24.setOwner(var19);
            var22.setItemMeta(var24);
            var4.add(var22);
         } else {
            var22 = new ItemStack(Material.GOLD_BLOCK);
            ItemMeta var241 = var22.getItemMeta();
            var23 = "";
            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 3) {
               var23 = "§a";
            }

            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() > 3 && Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 8) {
               var23 = "§e";
            }

            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() > 10) {
               var23 = "§c";
            }

            var241.setDisplayName("§e" + Bukkit.getPlayer(var19).getName() + " " + var23 + "° " + "§7(§c" + Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() + "§7)");
            var25 = new ArrayList();
            var25.add("");
            var25.add("§aReasons: ");
            if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() <= 5 && Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() != 1) {
               for(var26 = 0; var26 < Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size(); ++var26) {
                  if(!var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)")) {
                     var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)");
                  }
               }
            } else {
               if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() > 5) {
                  for(var26 = 0; var26 < Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size(); ++var26) {
                     if(!var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)")) {
                        var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(var26)).replace("_", " ")) + "§7)");
                     }
                  }

                  var25.add("§f...");
               }

               if(Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).size() == 1 && !var25.contains("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " "))) {
                  var25.add("§f" + ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(Bukkit.getPlayer(var19).getUniqueId(), ((String)Main.getDBS().getReasons(Bukkit.getPlayer(var19).getUniqueId()).get(0)).replace("_", " ")) + "§7)");
               }
            }

            var25.add("");
            var25.add("§aStatus: §fReviewed by " + Main.getStatus().getReviewer(Bukkit.getPlayer(var19).getUniqueId()));
            var25.add("");
            var241.setLore(var25);
            var22.setItemMeta(var241);
            var4.add(var22);
         }
      }

      Inventory var181 = Bukkit.createInventory((InventoryHolder)null, 54, "§cLocal reports");
      ItemStack var191 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var20 = var191.getItemMeta();
      var191.setDurability((short)15);
      var20.setDisplayName(" ");
      var20.setLore(Arrays.asList(new String[]{" "}));
      var191.setItemMeta(var20);

      for(int var21 = 45; var21 < 53; ++var21) {
         var181.setItem(var21, var191);
      }

      byte var221 = 45;
      int var251 = (var2 - 1) * var221;
      int var231 = var251 + var221;
      if(var231 > var4.size()) {
         var231 = var4.size();
         var3 = false;
      }

      Iterator var271 = var4.subList(var251, var231).iterator();

      ItemStack var261;
      while(var271.hasNext()) {
         var261 = (ItemStack)var271.next();
         var181.addItem(new ItemStack[]{var261});
      }

      ItemMeta var27;
      if(var2 != 1) {
         var261 = new ItemStack(Material.ARROW);
         var27 = var261.getItemMeta();
         var27.setDisplayName("§cBack");
         var261.setItemMeta(var27);
         var181.setItem(48, var261);
      } else {
         var261 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var27 = var261.getItemMeta();
         var261.setDurability((short)15);
         var27.setDisplayName("§cFirst page");
         var261.setItemMeta(var27);
         var181.setItem(48, var261);
      }

      var261 = new ItemStack(Material.REDSTONE);
      var27 = var261.getItemMeta();
      var27.setDisplayName("§ePage " + var2);
      var27.setLore(Arrays.asList(new String[]{"", "§eLeft click to reload the page", ""}));
      var261.setItemMeta(var27);
      var181.setItem(49, var261);
      ItemStack var13;
      ItemMeta var14;
      if(var3) {
         var13 = new ItemStack(Material.ARROW);
         var14 = var13.getItemMeta();
         var14.setDisplayName("§aForward");
         var13.setItemMeta(var14);
         var181.setItem(50, var13);
      } else {
         var13 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var14 = var13.getItemMeta();
         var13.setDurability((short)15);
         var14.setDisplayName("§cLast page");
         var13.setItemMeta(var14);
         var181.setItem(50, var13);
      }

      var13 = new ItemStack(Material.BARRIER);
      var14 = var13.getItemMeta();
      var14.setDisplayName("§cGo Back");
      var14.setLore(Arrays.asList(new String[]{"", "§fGo back to the main menù.", ""}));
      var13.setItemMeta(var14);
      var181.setItem(53, var13);
      ItemStack var15 = new ItemStack(Material.HOPPER);
      ItemMeta var16 = var15.getItemMeta();
      var16.setDisplayName("§eDelete local reports");
      var16.setLore(Arrays.asList(new String[]{"", "§fDelete all local reports.", ""}));
      var15.setItemMeta(var16);
      var181.setItem(45, var15);
      var1.openInventory(var181);
   }

   public void createGlobalReportsList(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§cGlobal reports");
      int var3 = ((Integer)this.pages3.get(var1)).intValue();
      boolean var4 = true;
      ItemStack var5 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var6 = var5.getItemMeta();
      var5.setDurability((short)15);
      var6.setDisplayName(" ");
      var6.setLore(Arrays.asList(new String[]{" "}));
      var5.setItemMeta(var6);

      for(int var17 = 45; var17 < 53; ++var17) {
         var2.setItem(var17, var5);
      }

      ArrayList var30 = new ArrayList();
      int var8;
      ItemStack var15;
      ItemMeta var16;
      byte var18;
      int var19;
      int var21;
      ItemStack var24;
      Iterator var28;
      ItemMeta var29;
      ItemStack var31;
      ItemMeta var34;
      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         for(var8 = 0; var8 < Main.getDBS().getReports().size(); ++var8) {
            UUID var20 = UUID.fromString((String)Main.getDBS().getReports().get(var8));
            ItemStack var27;
            if(!Main.getStatus().isReviewed(var20)) {
               var27 = new ItemStack(Material.PLAYER_HEAD, 1, (short)3);
               SkullMeta var32 = (SkullMeta)var27.getItemMeta();
               var32.setDisplayName("§e" + Bukkit.getPlayer(var20).getName() + " §a" + "° " + "§7(§c" + Main.getDBS().getReasons(var20).size() + "§7)");
               ArrayList var33 = new ArrayList();
               var33.add("");
               var33.add("§aServer: §f" + Main.getDBS().getServer(var20));
               var33.add("");
               var33.add("§aReasons: ");
               int var35;
               if(Main.getDBS().getReasons(var20).size() <= 5 && Main.getDBS().getReasons(var20).size() != 1) {
                  for(var35 = 0; var35 < Main.getDBS().getReasons(var20).size(); ++var35) {
                     if(!var33.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ")) + "§7)")) {
                        var33.add("§f" + ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ")) + "§7)");
                     }
                  }
               } else {
                  if(Main.getReportsLog().getReportReasons(Bukkit.getPlayer(var20)).size() > 5) {
                     for(var35 = 0; var35 < Main.getDBS().getReasons(var20).size(); ++var35) {
                        if(!var33.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ")) + "§7)")) {
                           var33.add("§f" + ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var35)).replace("_", " ")) + "§7)");
                        }
                     }

                     var33.add("§f...");
                  }

                  if(Main.getDBS().getReasons(var20).size() == 1 && !var33.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " "))) {
                     var33.add("§f" + ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " ")) + "§7)");
                  }
               }

               var33.add("");
               var33.add("§aStatus: §fOpen");
               var33.add("");
               var32.setOwner(Bukkit.getPlayer(var20).getName());
               var32.setLore(var33);
               var27.setItemMeta(var32);
               var30.add(var27);
            } else {
               var27 = new ItemStack(Material.GOLD_BLOCK);
               ItemMeta var331 = var27.getItemMeta();
               String var351 = "";
               if(Main.getDBS().getReasons(var20).size() <= 3) {
                  var351 = "§a";
               }

               if(Main.getDBS().getReasons(var20).size() > 3 && Main.getDBS().getReasons(var20).size() <= 8) {
                  var351 = "§e";
               }

               if(Main.getDBS().getReasons(var20).size() > 10) {
                  var351 = "§c";
               }

               var331.setDisplayName("§e" + Bukkit.getPlayer(var20).getName() + " " + var351 + "° " + "§7(§c" + Main.getDBS().getReasons(var20).size() + "§7)");
               ArrayList var371 = new ArrayList();
               var371.add("");
               var371.add("§aServer: §f" + Main.getDBS().getServer(var20));
               var371.add("");
               var371.add("§aReasons: ");
               int var36;
               if(Main.getDBS().getReasons(var20).size() <= 5 && Main.getDBS().getReasons(var20).size() != 1) {
                  for(var36 = 0; var36 < Main.getDBS().getReasons(var20).size(); ++var36) {
                     if(!var371.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ")) + "§7)")) {
                        var371.add("§f" + ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ")) + "§7)");
                     }
                  }
               } else {
                  if(Main.getDBS().getReasons(var20).size() > 5) {
                     for(var36 = 0; var36 < Main.getDBS().getReasons(var20).size(); ++var36) {
                        if(!var371.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ")) + "§7)")) {
                           var371.add("§f" + ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(var36)).replace("_", " ")) + "§7)");
                        }
                     }

                     var371.add("§f...");
                  }

                  if(Main.getDBS().getReasons(var20).size() == 1 && !var371.contains("§f" + ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " "))) {
                     var371.add("§f" + ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " ") + " §7(§c" + Main.getDBS().getSameReasonsNumber(var20, ((String)Main.getDBS().getReasons(var20).get(0)).replace("_", " ")) + "§7)");
                  }
               }

               var371.add("");
               var371.add("§aStatus: §fReviewed by " + Main.getStatus().getReviewer(var20));
               var371.add("");
               var331.setLore(var371);
               var27.setItemMeta(var331);
               var30.add(var27);
            }
         }

         var18 = 45;
         var19 = (var3 - 1) * var18;
         var21 = var19 + var18;
         if(var21 > var30.size()) {
            var21 = var30.size();
            var4 = false;
         }

         var28 = var30.subList(var19, var21).iterator();

         while(var28.hasNext()) {
            var24 = (ItemStack)var28.next();
            var2.addItem(new ItemStack[]{var24});
         }

         if(var3 != 1) {
            var24 = new ItemStack(Material.ARROW);
            var29 = var24.getItemMeta();
            var29.setDisplayName("§cBack");
            var24.setItemMeta(var29);
            var2.setItem(48, var24);
         } else {
            var24 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var29 = var24.getItemMeta();
            var24.setDurability((short)15);
            var29.setDisplayName("§cFirst page");
            var24.setItemMeta(var29);
            var2.setItem(48, var24);
         }

         var24 = new ItemStack(Material.REDSTONE);
         var29 = var24.getItemMeta();
         var29.setDisplayName("§ePage " + var3);
         var29.setLore(Arrays.asList(new String[]{"", "§eLeft click to reload the page", ""}));
         var24.setItemMeta(var29);
         var2.setItem(49, var24);
         if(var4) {
            var31 = new ItemStack(Material.ARROW);
            var34 = var31.getItemMeta();
            var34.setDisplayName("§aForward");
            var31.setItemMeta(var34);
            var2.setItem(50, var31);
         } else {
            var31 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var34 = var31.getItemMeta();
            var31.setDurability((short)15);
            var34.setDisplayName("§cLast page");
            var31.setItemMeta(var34);
            var2.setItem(50, var31);
         }

         var31 = new ItemStack(Material.BARRIER);
         var34 = var31.getItemMeta();
         var34.setDisplayName("§cGo Back");
         var34.setLore(Arrays.asList(new String[]{"", "§fGo back to the main menù.", ""}));
         var31.setItemMeta(var34);
         var2.setItem(53, var31);
         var15 = new ItemStack(Material.HOPPER);
         var16 = var15.getItemMeta();
         var16.setDisplayName("§eDelete reports");
         var16.setLore(Arrays.asList(new String[]{"", "§fDelete all reports.", ""}));
         var15.setItemMeta(var16);
         var2.setItem(45, var15);
      } else {
         ArrayList var37;
         int var38;
         String var39;
         ArrayList var40;
         String var311;
         Player var321;
         ItemStack var341;
         int var361;
         SkullMeta var381;
         ItemMeta var391;
         if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
            for(var8 = 0; var8 < Main.getReportsLog().getReports().size(); ++var8) {
               var311 = (String)Main.getReportsLog().getReports().get(var8);
               UUID var25 = UUID.fromString(var311);
               var321 = Bukkit.getPlayer(var25);
               if(!Main.getStatus().isReviewed(var321.getUniqueId())) {
                  var341 = new ItemStack(Material.PLAYER_HEAD, 1, (short)3);
                  var381 = (SkullMeta)var341.getItemMeta();
                  var381.setDisplayName("§e" + var321.getName() + " §a" + "° " + "§7(§c" + Main.getReportsLog().getReportReasons(var321).size() + "§7)");
                  var37 = new ArrayList();
                  var37.add("");
                  var37.add("§aReasons: ");
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 5 && Main.getReportsLog().getReportReasons(var321).size() != 1) {
                     for(var361 = 0; var361 < Main.getReportsLog().getReportReasons(var321).size(); ++var361) {
                        if(!var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)")) {
                           var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)");
                        }
                     }
                  } else {
                     if(Main.getReportsLog().getReportReasons(var321).size() > 5) {
                        for(var361 = 0; var361 < Main.getReportsLog().getReportReasons(var321).size(); ++var361) {
                           if(!var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)")) {
                              var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)");
                           }
                        }

                        var37.add("§f...");
                     }

                     if(Main.getReportsLog().getReportReasons(var321).size() == 1 && !var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " "))) {
                        var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ")) + "§7)");
                     }
                  }

                  var37.add("");
                  var37.add("§aStatus: §fOpen");
                  var37.add("");
                  var381.setOwner(var321.getName());
                  var381.setLore(var37);
                  var341.setItemMeta(var381);
                  var30.add(var341);
               } else {
                  var341 = new ItemStack(Material.GOLD_BLOCK);
                  var391 = var341.getItemMeta();
                  var39 = "";
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 3) {
                     var39 = "§a";
                  }

                  if(Main.getReportsLog().getReportReasons(var321).size() > 3 && Main.getReportsLog().getReportReasons(var321).size() <= 8) {
                     var39 = "§e";
                  }

                  if(Main.getReportsLog().getReportReasons(var321).size() > 10) {
                     var39 = "§c";
                  }

                  var391.setDisplayName("§e" + var321.getName() + " " + var39 + "° " + "§7(§c" + Main.getReportsLog().getReportReasons(var321).size() + "§7)");
                  var40 = new ArrayList();
                  var40.add("");
                  var40.add("§aReasons: ");
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 5 && Main.getReportsLog().getReportReasons(var321).size() != 1) {
                     for(var38 = 0; var38 < Main.getReportsLog().getReportReasons(var321).size(); ++var38) {
                        if(!var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)")) {
                           var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)");
                        }
                     }
                  } else {
                     if(Main.getReportsLog().getReportReasons(var321).size() > 5) {
                        for(var38 = 0; var38 < Main.getReportsLog().getReportReasons(var321).size(); ++var38) {
                           if(!var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)")) {
                              var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)");
                           }
                        }

                        var40.add("§f...");
                     }

                     if(Main.getReportsLog().getReportReasons(var321).size() == 1 && !var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " "))) {
                        var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ")) + "§7)");
                     }
                  }

                  var40.add("");
                  var40.add("§aStatus: §fReviewed by " + Main.getStatus().getReviewer(var321.getUniqueId()));
                  var40.add("");
                  var391.setLore(var40);
                  var341.setItemMeta(var391);
                  var30.add(var341);
               }
            }
         } else {
            for(var8 = 0; var8 < Main.getReportsLog().getReports().size(); ++var8) {
               var311 = (String)Main.getReportsLog().getReports().get(var8);
               String var401 = var311.split(":")[0];
               var321 = Bukkit.getPlayer(var401);
               if(!Main.getStatus().isReviewed(var321.getUniqueId())) {
                  var341 = new ItemStack(Material.PLAYER_HEAD, 1, (short)3);
                  var381 = (SkullMeta)var341.getItemMeta();
                  var381.setDisplayName("§e" + var321.getName() + " §a" + "° " + "§7(§c" + Main.getReportsLog().getReportReasons(var321).size() + "§7)");
                  var37 = new ArrayList();
                  var37.add("");
                  var37.add("§aReasons: ");
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 5 && Main.getReportsLog().getReportReasons(var321).size() != 1) {
                     for(var361 = 0; var361 < Main.getReportsLog().getReportReasons(var321).size(); ++var361) {
                        if(!var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)")) {
                           var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)");
                        }
                     }
                  } else {
                     if(Main.getReportsLog().getReportReasons(var321).size() > 5) {
                        for(var361 = 0; var361 < Main.getReportsLog().getReportReasons(var321).size(); ++var361) {
                           if(!var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)")) {
                              var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var361)).replace("_", " ")) + "§7)");
                           }
                        }

                        var37.add("§f...");
                     }

                     if(Main.getReportsLog().getReportReasons(var321).size() == 1 && !var37.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " "))) {
                        var37.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ")) + "§7)");
                     }
                  }

                  var37.add("");
                  var37.add("§aStatus: §fOpen");
                  var37.add("");
                  var381.setOwner(var321.getName());
                  var381.setLore(var37);
                  var341.setItemMeta(var381);
                  var30.add(var341);
               } else {
                  var341 = new ItemStack(Material.GOLD_BLOCK);
                  var391 = var341.getItemMeta();
                  var39 = "";
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 3) {
                     var39 = "§a";
                  }

                  if(Main.getReportsLog().getReportReasons(var321).size() > 3 && Main.getReportsLog().getReportReasons(var321).size() <= 8) {
                     var39 = "§e";
                  }

                  if(Main.getReportsLog().getReportReasons(var321).size() > 10) {
                     var39 = "§c";
                  }

                  var391.setDisplayName("§e" + var321.getName() + " " + var39 + "° " + "§7(§c" + Main.getReportsLog().getReportReasons(var321).size() + "§7)");
                  var40 = new ArrayList();
                  var40.add("");
                  var40.add("§aReasons: ");
                  if(Main.getReportsLog().getReportReasons(var321).size() <= 5 && Main.getReportsLog().getReportReasons(var321).size() != 1) {
                     for(var38 = 0; var38 < Main.getReportsLog().getReportReasons(var321).size(); ++var38) {
                        if(!var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)")) {
                           var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)");
                        }
                     }
                  } else {
                     if(Main.getReportsLog().getReportReasons(var321).size() > 5) {
                        for(var38 = 0; var38 < Main.getReportsLog().getReportReasons(var321).size(); ++var38) {
                           if(!var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)")) {
                              var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(var38)).replace("_", " ")) + "§7)");
                           }
                        }

                        var40.add("§f...");
                     }

                     if(Main.getReportsLog().getReportReasons(var321).size() == 1 && !var40.contains("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " "))) {
                        var40.add("§f" + ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ") + " §7(§c" + Main.getReportsLog().getSameReasonsNumber(var321, ((String)Main.getReportsLog().getReportReasons(var321).get(0)).replace("_", " ")) + "§7)");
                     }
                  }

                  var40.add("");
                  var40.add("§aStatus: §fReviewed by " + Main.getStatus().getReviewer(var321.getUniqueId()));
                  var40.add("");
                  var391.setLore(var40);
                  var341.setItemMeta(var391);
                  var30.add(var341);
               }
            }
         }

         var18 = 45;
         var19 = (var3 - 1) * var18;
         var21 = var19 + var18;
         if(var21 > var30.size()) {
            var21 = var30.size();
            var4 = false;
         }

         var28 = var30.subList(var19, var21).iterator();

         while(var28.hasNext()) {
            var24 = (ItemStack)var28.next();
            var2.addItem(new ItemStack[]{var24});
         }

         if(var3 != 1) {
            var24 = new ItemStack(Material.ARROW);
            var29 = var24.getItemMeta();
            var29.setDisplayName("§cBack");
            var24.setItemMeta(var29);
            var2.setItem(48, var24);
         } else {
            var24 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var29 = var24.getItemMeta();
            var24.setDurability((short)15);
            var29.setDisplayName("§cFirst page");
            var24.setItemMeta(var29);
            var2.setItem(48, var24);
         }

         var24 = new ItemStack(Material.REDSTONE);
         var29 = var24.getItemMeta();
         var29.setDisplayName("§ePage " + var3);
         var29.setLore(Arrays.asList(new String[]{"", "§eLeft click to reload the page", ""}));
         var24.setItemMeta(var29);
         var2.setItem(49, var24);
         if(var4) {
            var31 = new ItemStack(Material.ARROW);
            var34 = var31.getItemMeta();
            var34.setDisplayName("§aForward");
            var31.setItemMeta(var34);
            var2.setItem(50, var31);
         } else {
            var31 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var34 = var31.getItemMeta();
            var31.setDurability((short)15);
            var34.setDisplayName("§cLast page");
            var31.setItemMeta(var34);
            var2.setItem(50, var31);
         }

         var31 = new ItemStack(Material.BARRIER);
         var34 = var31.getItemMeta();
         var34.setDisplayName("§cGo Back");
         var34.setLore(Arrays.asList(new String[]{"", "§fGo back to the main menù.", ""}));
         var31.setItemMeta(var34);
         var2.setItem(53, var31);
         var15 = new ItemStack(Material.HOPPER);
         var16 = var15.getItemMeta();
         var16.setDisplayName("§eDelete reports");
         var16.setLore(Arrays.asList(new String[]{"", "§fDelete all reports.", ""}));
         var15.setItemMeta(var16);
         var2.setItem(45, var15);
      }

      var1.openInventory(var2);
   }

   public void createPlayerManagerGui(Player var1, Player var2) {
      try {
         Inventory var22 = Bukkit.createInventory((InventoryHolder)null, 27, "§cManage §c" + var2.getName());
         ItemStack var4 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         ItemMeta var5 = var4.getItemMeta();
         var4.setDurability((short)15);
         var5.setDisplayName(" ");
         var5.setLore(Arrays.asList(new String[]{" "}));
         var4.setItemMeta(var5);

         for(int var23 = 0; var23 < var22.getSize(); ++var23) {
            var22.setItem(var23, var4);
         }

         ItemStack var231 = new ItemStack(Material.LEGACY_WRITTEN_BOOK);
         ItemMeta var7 = var231.getItemMeta();
         var7.setDisplayName("§eComment");
         var7.setLore(Arrays.asList(new String[]{"", "§fClose this report with a comment", "", "§fThis report will go to the", "§fsolved reports section.", "", "§7Write in chat a reason", "§7for the close of the report", ""}));
         var231.setItemMeta(var7);
         var22.setItem(9, var231);
         ItemStack var8 = new ItemStack(Material.IRON_BOOTS);
         ItemMeta var9 = var8.getItemMeta();
         var9.setDisplayName("§eTeleport");
         var9.setLore(Arrays.asList(new String[]{"", "§fTeleport to §6" + var2.getName(), "", "§7You must be in the same server of " + var2.getName(), ""}));
         var8.setItemMeta(var9);
         var22.setItem(2, var8);
         ItemStack var10 = new ItemStack(Material.ANVIL);
         ItemMeta var11 = var10.getItemMeta();
         var11.setDisplayName("§cBan");
         var11.setLore(Arrays.asList(new String[]{"", "§fBan " + var2.getName() + " from the server.", "", "§7Write in chat a reason", "§7for the ban.", ""}));
         var10.setItemMeta(var11);
         var22.setItem(4, var10);
         ItemStack var12 = new ItemStack(Material.BOOK);
         ItemMeta var13 = var12.getItemMeta();
         var13.setDisplayName("§eData");
         InetSocketAddress var14 = var2.getAddress();
         String var15 = var14.toString();
         var13.setLore(Arrays.asList(new String[]{"", "§eName: §f" + var2.getName(), "", "§eUUID:§f " + var2.getUniqueId(), "", "§eIP:§f " + var15, "", "§eTotal reports:§f " + (Main.getInstance().getConfig().getBoolean("Settings.bungeecord")?Main.getDBS().getSolvedReportsOf(var2.getUniqueId()):Main.getSolvedReportsLog().getSolvedReportsOf(var2.getName())), ""}));
         var12.setItemMeta(var13);
         var22.setItem(24, var12);
         ItemStack var16 = new ItemStack(Material.REDSTONE);
         ItemMeta var17 = var16.getItemMeta();
         var17.setDisplayName("§cKick");
         var17.setLore(Arrays.asList(new String[]{"", "§fKick §6" + var2.getName() + "§f from the server.", "", "§7Write in chat a reason", "§7for the kick.", ""}));
         var16.setItemMeta(var17);
         var22.setItem(22, var16);
         ItemStack var18 = new ItemStack(Material.PAPER);
         ItemMeta var19 = var18.getItemMeta();
         var19.setDisplayName("§cMute");
         var19.setLore(Arrays.asList(new String[]{"", "§fMute §6" + var2.getName() + "§f for 15 minutes.", "", "§7Write in chat a reason", "§7for the mute.", ""}));
         var18.setItemMeta(var19);
         var22.setItem(6, var18);
         ItemStack var20;
         ItemMeta var21;
         if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
            var20 = new ItemStack(Material.FEATHER);
            var21 = var20.getItemMeta();
            var21.setDisplayName("§eServer");
            var21.setLore(Arrays.asList(new String[]{"", "§fLeft click to know §6" + var2.getName() + "§e\'s server", ""}));
            var20.setItemMeta(var21);
            var22.setItem(20, var20);
         } else {
            var20 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var21 = var20.getItemMeta();
            var20.setDurability((short)15);
            var21.setDisplayName("§cBungeecord is disabled");
            var21.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with a non-bungeecord server.", ""}));
            var20.setItemMeta(var21);
            var22.setItem(20, var20);
         }

         var20 = new ItemStack(Material.HOPPER);
         var21 = var20.getItemMeta();
         var21.setDisplayName("§eDelete report");
         var21.setLore(Arrays.asList(new String[]{"", "§fDelete report of §6" + var2.getName(), "§f from the database.", ""}));
         var20.setItemMeta(var21);
         var22.setItem(17, var20);
         var1.openInventory(var22);
      } catch (Exception var221) {
         var221.printStackTrace();
      }

   }

   public void createOfflinePlayerManagerGui(Player var1, OfflinePlayer var2) {
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 27, "§cManage §c" + var2.getName());
      ItemStack var4 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var5 = var4.getItemMeta();
      var4.setDurability((short)15);
      var5.setDisplayName(" ");
      var5.setLore(Arrays.asList(new String[]{" "}));
      var4.setItemMeta(var5);

      for(int var7 = 0; var7 < var3.getSize(); ++var7) {
         var3.setItem(var7, var4);
      }

      ItemStack var8;
      ItemMeta var9;
      ItemStack var10;
      ItemMeta var11;
      ItemStack var12;
      ItemMeta var13;
      ItemStack var14;
      ItemMeta var15;
      ItemStack var16;
      ItemMeta var17;
      ItemStack var18;
      ItemMeta var19;
      ItemStack var20;
      ItemMeta var201;
      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         var20 = new ItemStack(Material.LEGACY_WRITTEN_BOOK);
         var201 = var20.getItemMeta();
         var201.setDisplayName("§eComment");
         var201.setLore(Arrays.asList(new String[]{"", "§fClose this report with a comment", "", "§fThis report will go to the", "§fsolved reports section.", "", "§7Write in chat a reason", "§7for the close of the report", ""}));
         var20.setItemMeta(var201);
         var3.setItem(9, var20);
         var8 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var9 = var8.getItemMeta();
         var8.setDurability((short)15);
         var9.setDisplayName("§cTeleport");
         var9.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var8.setItemMeta(var9);
         var3.setItem(2, var8);
         var10 = new ItemStack(Material.ANVIL);
         var11 = var10.getItemMeta();
         var11.setDisplayName("§cBan");
         var11.setLore(Arrays.asList(new String[]{"", "§fBan " + var2.getName() + " from the server.", "", "§7Write in chat a reason", "§7for the ban.", ""}));
         var10.setItemMeta(var11);
         var3.setItem(4, var10);
         var12 = new ItemStack(Material.BOOK);
         var13 = var12.getItemMeta();
         var13.setDisplayName("§eData");
         var13.setLore(Arrays.asList(new String[]{"", "§eName: §f" + var2.getName(), "", "§eUUID:§f " + var2.getUniqueId(), "", "§eTotal reports:§f " + Main.getDBS().getSolvedReportsOf(var2.getUniqueId()), ""}));
         var12.setItemMeta(var13);
         var3.setItem(24, var12);
         var14 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var15 = var14.getItemMeta();
         var14.setDurability((short)15);
         var15.setDisplayName("§cKick");
         var15.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var14.setItemMeta(var15);
         var3.setItem(22, var14);
         var16 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var17 = var16.getItemMeta();
         var16.setDurability((short)15);
         var17.setDisplayName("§cMute");
         var17.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var16.setItemMeta(var17);
         var3.setItem(6, var16);
         if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
            var18 = new ItemStack(Material.FEATHER);
            var19 = var18.getItemMeta();
            var19.setDisplayName("§eServer");
            var19.setLore(Arrays.asList(new String[]{"", "§fLeft click to know  §6" + var2.getName() + "§e\'s server", ""}));
            var18.setItemMeta(var19);
            var3.setItem(20, var18);
         } else {
            var18 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var19 = var18.getItemMeta();
            var18.setDurability((short)15);
            var19.setDisplayName("§cBungeecord is disabled");
            var19.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with a non-bungeecord server.", ""}));
            var18.setItemMeta(var19);
            var3.setItem(20, var18);
         }

         var18 = new ItemStack(Material.HOPPER);
         var19 = var18.getItemMeta();
         var19.setDisplayName("§eDelete report");
         var19.setLore(Arrays.asList(new String[]{"", "§fDelete report of §6" + var2.getName(), "§f from the database.", ""}));
         var18.setItemMeta(var19);
         var3.setItem(17, var18);
      } else {
         var20 = new ItemStack(Material.LEGACY_WRITTEN_BOOK);
         var201 = var20.getItemMeta();
         var201.setDisplayName("§eComment");
         var201.setLore(Arrays.asList(new String[]{"", "§fClose this report with a comment", "", "§fThis report will go to the", "§fsolved reports section.", "", "§7Write in chat a reason", "§7for the close of the report", ""}));
         var20.setItemMeta(var201);
         var3.setItem(9, var20);
         var8 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var9 = var8.getItemMeta();
         var8.setDurability((short)15);
         var9.setDisplayName("§cTeleport");
         var9.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var8.setItemMeta(var9);
         var3.setItem(2, var8);
         var10 = new ItemStack(Material.ANVIL);
         var11 = var10.getItemMeta();
         var11.setDisplayName("§cBan");
         var11.setLore(Arrays.asList(new String[]{"", "§fBan " + var2.getName() + " from the server.", "", "§7Write in chat a reason", "§7for the ban.", ""}));
         var10.setItemMeta(var11);
         var3.setItem(4, var10);
         var12 = new ItemStack(Material.BOOK);
         var13 = var12.getItemMeta();
         var13.setDisplayName("§eData");
         var13.setLore(Arrays.asList(new String[]{"", "§eName: §f" + var2.getName(), "", "§eUUID:§f " + var2.getUniqueId(), "", "§eTotal reports:§f " + Main.getSolvedReportsLog().getSolvedReportsOf(var2.getName()), ""}));
         var12.setItemMeta(var13);
         var3.setItem(24, var12);
         var14 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var15 = var14.getItemMeta();
         var14.setDurability((short)15);
         var15.setDisplayName("§cKick");
         var15.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var14.setItemMeta(var15);
         var3.setItem(22, var14);
         var16 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
         var17 = var16.getItemMeta();
         var16.setDurability((short)15);
         var17.setDisplayName("§cMute");
         var17.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with an offline target.", ""}));
         var16.setItemMeta(var17);
         var3.setItem(6, var16);
         if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
            var18 = new ItemStack(Material.FEATHER);
            var19 = var18.getItemMeta();
            var19.setDisplayName("§eServer");
            var19.setLore(Arrays.asList(new String[]{"", "§fLeft click to know  §6" + var2.getName() + "§e\'s server", ""}));
            var18.setItemMeta(var19);
            var3.setItem(20, var18);
         } else {
            var18 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var19 = var18.getItemMeta();
            var18.setDurability((short)15);
            var19.setDisplayName("§cBungeecord is disabled");
            var19.setLore(Arrays.asList(new String[]{"", "§7Feature disabled with a non-bungeecord server.", ""}));
            var18.setItemMeta(var19);
            var3.setItem(20, var18);
         }

         var18 = new ItemStack(Material.HOPPER);
         var19 = var18.getItemMeta();
         var19.setDisplayName("§eDelete report");
         var19.setLore(Arrays.asList(new String[]{"", "§fDelete report of §6" + var2.getName(), "§f from the database.", ""}));
         var18.setItemMeta(var19);
         var3.setItem(17, var18);
      }

      var1.openInventory(var3);
   }

   public void createSolvedReportsGui(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§2Solved reports");
      int var3 = ((Integer)this.pages2.get(var1)).intValue();
      boolean var4 = true;
      ItemStack var5 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var6 = var5.getItemMeta();
      var5.setDurability((short)15);
      var6.setDisplayName(" ");
      var6.setLore(Arrays.asList(new String[]{" "}));
      var5.setItemMeta(var6);

      for(int var17 = 45; var17 < 53; ++var17) {
         var2.setItem(var17, var5);
      }

      ArrayList var241 = new ArrayList();
      int var8;
      String var10;
      String var11;
      ItemMeta var14;
      ItemStack var15;
      ItemMeta var16;
      byte var18;
      int var19;
      int var21;
      ItemStack var22;
      Iterator var23;
      ItemMeta var24;
      ItemStack var25;
      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         for(var8 = 0; var8 < Main.getDBS().getSolvedReports().size(); ++var8) {
            UUID var20 = (UUID)Main.getDBS().getSolvedReports().get(var8);
            var10 = Bukkit.getPlayer((String)Main.getDBS().getStaffers().get(var8)).getName();
            var11 = ((String)Main.getDBS().getComments().get(var8)).replace("_", " ");
            ItemStack var26 = new ItemStack(Material.EMERALD_BLOCK);
            ItemMeta var13 = var26.getItemMeta();
            var13.setDisplayName("§2" + Bukkit.getPlayer(var20).getName());
            var13.setLore(Arrays.asList(new String[]{"", "§aComment: §f" + var11, "", "§aSolved by:§f " + var10, ""}));
            var26.setItemMeta(var13);
            var241.add(var26);
         }

         var18 = 45;
         var19 = (var3 - 1) * var18;
         var21 = var19 + var18;
         if(var21 > var241.size()) {
            var21 = var241.size();
            var4 = false;
         }

         var23 = var241.subList(var19, var21).iterator();

         while(var23.hasNext()) {
            var22 = (ItemStack)var23.next();
            var2.addItem(new ItemStack[]{var22});
         }

         if(var3 != 1) {
            var22 = new ItemStack(Material.ARROW);
            var24 = var22.getItemMeta();
            var24.setDisplayName("§cBack");
            var22.setItemMeta(var24);
            var2.setItem(48, var22);
         } else {
            var22 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var24 = var22.getItemMeta();
            var22.setDurability((short)15);
            var24.setDisplayName("§cFirst page");
            var22.setItemMeta(var24);
            var2.setItem(48, var22);
         }

         var22 = new ItemStack(Material.REDSTONE);
         var24 = var22.getItemMeta();
         var24.setDisplayName("§ePage " + var3);
         var24.setLore(Arrays.asList(new String[]{"", "§eLeft click to reload the page", ""}));
         var22.setItemMeta(var24);
         var2.setItem(49, var22);
         if(var4) {
            var25 = new ItemStack(Material.ARROW);
            var14 = var25.getItemMeta();
            var14.setDisplayName("§aForward");
            var25.setItemMeta(var14);
            var2.setItem(50, var25);
         } else {
            var25 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var14 = var25.getItemMeta();
            var25.setDurability((short)15);
            var14.setDisplayName("§cLast page");
            var25.setItemMeta(var14);
            var2.setItem(50, var25);
         }

         var25 = new ItemStack(Material.BARRIER);
         var14 = var25.getItemMeta();
         var14.setDisplayName("§cGo Back");
         var14.setLore(Arrays.asList(new String[]{"", "§fGo back to the main menù.", ""}));
         var25.setItemMeta(var14);
         var2.setItem(53, var25);
         var15 = new ItemStack(Material.HOPPER);
         var16 = var15.getItemMeta();
         var16.setDisplayName("§eDelete solved reports");
         var16.setLore(Arrays.asList(new String[]{"", "§fDelete all solved reports.", ""}));
         var15.setItemMeta(var16);
         var2.setItem(45, var15);
         var1.openInventory(var2);
      } else {
         for(var8 = 0; var8 < Main.getSolvedReportsLog().getSolvedReports().size(); ++var8) {
            String[] var251 = ((String)Main.getSolvedReportsLog().getSolvedReports().get(var8)).split(":");
            var10 = var251[0];
            var11 = Bukkit.getPlayer((String)Main.getSolvedReportsLog().getStaffers().get(var8)).getName();
            String var261 = ((String)Main.getSolvedReportsLog().getReasons().get(var8)).replace("_", " ");
            var25 = new ItemStack(Material.EMERALD_BLOCK);
            var14 = var25.getItemMeta();
            var14.setDisplayName("§2" + var10);
            var14.setLore(Arrays.asList(new String[]{"", "§aComment: §f" + var261, "", "§aSolved by:§f " + var11, ""}));
            var25.setItemMeta(var14);
            var241.add(var25);
         }

         var18 = 45;
         var19 = (var3 - 1) * var18;
         var21 = var19 + var18;
         if(var21 > var241.size()) {
            var21 = var241.size();
            var4 = false;
         }

         var23 = var241.subList(var19, var21).iterator();

         while(var23.hasNext()) {
            var22 = (ItemStack)var23.next();
            var2.addItem(new ItemStack[]{var22});
         }

         if(var3 != 1) {
            var22 = new ItemStack(Material.ARROW);
            var24 = var22.getItemMeta();
            var24.setDisplayName("§cBack");
            var22.setItemMeta(var24);
            var2.setItem(48, var22);
         } else {
            var22 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var24 = var22.getItemMeta();
            var22.setDurability((short)15);
            var24.setDisplayName("§cFirst page");
            var22.setItemMeta(var24);
            var2.setItem(48, var22);
         }

         var22 = new ItemStack(Material.REDSTONE);
         var24 = var22.getItemMeta();
         var24.setDisplayName("§ePage " + var3);
         var24.setLore(Arrays.asList(new String[]{"", "§eLeft click to reload the page", ""}));
         var22.setItemMeta(var24);
         var2.setItem(49, var22);
         if(var4) {
            var25 = new ItemStack(Material.ARROW);
            var14 = var25.getItemMeta();
            var14.setDisplayName("§aForward");
            var25.setItemMeta(var14);
            var2.setItem(50, var25);
         } else {
            var25 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            var14 = var25.getItemMeta();
            var25.setDurability((short)15);
            var14.setDisplayName("§cLast page");
            var25.setItemMeta(var14);
            var2.setItem(50, var25);
         }

         var25 = new ItemStack(Material.BARRIER);
         var14 = var25.getItemMeta();
         var14.setDisplayName("§cGo Back");
         var14.setLore(Arrays.asList(new String[]{"", "§fGo back to the main menù.", ""}));
         var25.setItemMeta(var14);
         var2.setItem(53, var25);
         var15 = new ItemStack(Material.HOPPER);
         var16 = var15.getItemMeta();
         var16.setDisplayName("§eDelete solved reports");
         var16.setLore(Arrays.asList(new String[]{"", "§fDelete all solved reports.", ""}));
         var15.setItemMeta(var16);
         var2.setItem(45, var15);
      }

      var1.openInventory(var2);
   }

   public void createConfirmGui(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 9, "§cAre you sure?");
      ItemStack var3 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var4 = var3.getItemMeta();
      var3.setDurability((short)5);
      var4.setDisplayName("§aYes");
      var4.setLore(Arrays.asList(new String[]{"", "§fI want to delete permanently all local reports.", ""}));
      var3.setItemMeta(var4);
      var2.setItem(2, var3);
      ItemStack var5 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var6 = var5.getItemMeta();
      var5.setDurability((short)14);
      var6.setDisplayName("§cNo");
      var6.setLore(Arrays.asList(new String[]{"", "§fI dont want", ""}));
      var5.setItemMeta(var6);
      var2.setItem(6, var5);
      var1.openInventory(var2);
   }

   public void createConfirmGui2(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 9, "§cAre you sure? ");
      ItemStack var3 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var4 = var3.getItemMeta();
      var3.setDurability((short)5);
      var4.setDisplayName("§aYes");
      var4.setLore(Arrays.asList(new String[]{"", "§fI want to delete permanently every solved report.", ""}));
      var3.setItemMeta(var4);
      var2.setItem(2, var3);
      ItemStack var5 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var6 = var5.getItemMeta();
      var5.setDurability((short)14);
      var6.setDisplayName("§cNo");
      var6.setLore(Arrays.asList(new String[]{"", "§fI dont want", ""}));
      var5.setItemMeta(var6);
      var2.setItem(6, var5);
      var1.openInventory(var2);
   }

   public void createConfirmGui3(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 9, "§cAre you sure?  ");
      ItemStack var3 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var4 = var3.getItemMeta();
      var3.setDurability((short)5);
      var4.setDisplayName("§aYes");
      var4.setLore(Arrays.asList(new String[]{"", "§fI want to delete permanently every report.", ""}));
      var3.setItemMeta(var4);
      var2.setItem(2, var3);
      ItemStack var5 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta var6 = var5.getItemMeta();
      var5.setDurability((short)14);
      var6.setDisplayName("§cNo");
      var6.setLore(Arrays.asList(new String[]{"", "§fI dont want", ""}));
      var5.setItemMeta(var6);
      var2.setItem(6, var5);
      var1.openInventory(var2);
   }
}
