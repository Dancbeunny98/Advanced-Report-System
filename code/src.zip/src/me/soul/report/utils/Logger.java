package me.soul.report.utils;

import me.soul.report.Main;
import org.bukkit.entity.Player;

public class Logger {

   public static void log(Player var0, String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.prefix")) {
         var0.sendMessage(Main.getLanguages().getLanguages().getString("prefix").replace("&", "§") + Main.getLanguages().getLanguages().getString(var1).replace("&", "§").replace("%player%", var0.getName()).replace("%n%", String.valueOf(Main.getReportsLog().getReports().size())));
      } else {
         var0.sendMessage(Main.getLanguages().getLanguages().getString(var1).replace("&", "§").replace("%player%", var0.getName()).replace("%n%", String.valueOf(Main.getReportsLog().getReports().size())));
      }

   }

   public static void adminLog(String var0, Player var1, Player var2, Player var3, String var4, String var5) {
      if(Main.getInstance().getConfig().getBoolean("Settings.prefix")) {
         var1.sendMessage(Main.getLanguages().getLanguages().getString("prefix").replace("&", "§") + Main.getLanguages().getLanguages().getString(var0).replace("&", "§").replace("%player%", var2.getName()).replace("%server%", var4).replace("%reason%", var5).replace("%target%", var3.getName()));
      } else {
         var1.sendMessage(Main.getLanguages().getLanguages().getString(var0).replace("&", "§").replace("%player%", var2.getName()).replace("%server%", var4).replace("%reason%", var5).replace("%target%", var3.getName()));
      }

   }
}
