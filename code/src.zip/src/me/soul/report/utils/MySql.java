package me.soul.report.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import me.soul.report.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

public class MySql {

   private static String username;
   private static String password;
   private static String database;
   private static String host;
   private static int port;
   private static Connection co;


   public void connect() {
      if(!this.isConnected()) {
         try {
            co = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);
            Bukkit.getConsoleSender().sendMessage("§aSuccessfully connected to MySql database");
         } catch (SQLException var2) {
            var2.printStackTrace();
         }
      }

   }

   public boolean isConnected() {
      return this.getCo() != null;
   }

   public void disconnect() {
      if(this.isConnected()) {
         try {
            this.getCo().close();
         } catch (SQLException var2) {
            var2.printStackTrace();
         }
      }

   }

   public void createReportsTable() {
      if(this.isConnected()) {
         try {
            this.getCo().createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS FearReports (UUID VARCHAR(100), Reason VARCHAR(100), Server VARCHAR(100));");
         } catch (SQLException var2) {
            var2.printStackTrace();
         }
      }

   }

   public void createStatusTable() {
      if(this.isConnected()) {
         try {
            this.getCo().createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS FearStatus (UUID VARCHAR(100), Staffer VARCHAR(100));");
         } catch (SQLException var2) {
            var2.printStackTrace();
         }
      }

   }

   public void createSolvedReportsTable() {
      if(this.isConnected()) {
         try {
            this.getCo().createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS FearSolvedReports (UUID VARCHAR(100), Staffer VARCHAR(100), Comment VARCHAR(100));");
         } catch (SQLException var2) {
            var2.printStackTrace();
         }
      }

   }

   public void getMySQL() {
      FileConfiguration var1 = Main.getInstance().getConfig();
      username = var1.getString("MySql.username");
      password = var1.getString("MySql.password");
      database = var1.getString("MySql.database");
      host = var1.getString("MySql.host");
      port = var1.getInt("MySql.port");
   }

   public void update(String var1) {
      try {
         PreparedStatement var3 = Main.getSql().getCo().prepareStatement(var1);
         var3.executeUpdate();
         var3.close();
      } catch (SQLException var31) {
         var31.printStackTrace();
      }

   }

   public Connection getCo() {
      return co;
   }
}
