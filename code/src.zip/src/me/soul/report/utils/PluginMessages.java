package me.soul.report.utils;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Iterator;
import me.soul.report.Main;
import me.soul.report.utils.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PluginMessages {

   public void sendReport(String var1, String var2, String var3, String var4) {
      Logger.log(Bukkit.getPlayer(var1), "report_sended");
      Iterator var6 = Bukkit.getOnlinePlayers().iterator();

      while(var6.hasNext()) {
         Player var10 = (Player)var6.next();
         if(var10.hasPermission("reportsystem.admin")) {
            Logger.adminLog("report", var10, Bukkit.getPlayer(var1), Bukkit.getPlayer(var2), var4.toUpperCase(), var3);
         }
      }

      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         ByteArrayDataOutput var102 = ByteStreams.newDataOutput();
         var102.writeUTF("Forward");
         var102.writeUTF("ALL");
         var102.writeUTF("ReportSystem");
         ByteArrayOutputStream var11 = new ByteArrayOutputStream();
         DataOutputStream var7 = new DataOutputStream(var11);

         try {
            var7.writeUTF("sr " + var1 + " " + var2 + " " + var3.replace(" ", "_") + " " + var4);
         } catch (IOException var101) {
            var101.printStackTrace();
         }

         var102.writeShort(var11.toByteArray().length);
         var102.write(var11.toByteArray());
         Bukkit.getPlayer(var1).sendPluginMessage(Main.getInstance(), "ReportSystem", var102.toByteArray());
      }

   }

   public void sendCloseReportMessage(String var1, String var2, String var3, String var4) {
      Iterator var6 = Bukkit.getOnlinePlayers().iterator();

      while(var6.hasNext()) {
         Player var10 = (Player)var6.next();
         if(var10.hasPermission("reportsystem.admin")) {
            Logger.adminLog("close_report", var10, Bukkit.getPlayer(var1), Bukkit.getPlayer(var2), var4.toUpperCase(), var3);
         }
      }

      if(Main.getInstance().getConfig().getBoolean("Settings.bungeecord")) {
         ByteArrayDataOutput var102 = ByteStreams.newDataOutput();
         var102.writeUTF("Forward");
         var102.writeUTF("ALL");
         var102.writeUTF("ReportSystem");
         ByteArrayOutputStream var11 = new ByteArrayOutputStream();
         DataOutputStream var7 = new DataOutputStream(var11);

         try {
            var7.writeUTF("c " + var1 + " " + var2 + " " + var3.replace(" ", "_") + " " + var4);
         } catch (IOException var101) {
            var101.printStackTrace();
         }

         var102.writeShort(var11.toByteArray().length);
         var102.write(var11.toByteArray());
         Bukkit.getPlayer(var1).sendPluginMessage(Main.getInstance(), "ReportSystem", var102.toByteArray());
      }

   }
}
