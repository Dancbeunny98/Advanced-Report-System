package me.soul.report.utils;

import java.util.UUID;
import me.soul.report.Main;
import org.bukkit.Bukkit;

public class StatusUtils {

   public boolean isOpen(UUID var1) {
      return Main.getInstance().getConfig().getBoolean("Settings.mysql")?!Main.getDBS().isOpen(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var1))?Bukkit.getPlayer(var1).getUniqueId():Bukkit.getOfflinePlayer(var1).getUniqueId()):Main.getStatusLog().isOpen(Bukkit.getPlayer(var1).getName());
   }

   public boolean hasReview(String var1) {
      return Main.getInstance().getConfig().getBoolean("Settings.mysql")?Main.getDBS().hasReview(var1):Main.getStatusLog().hasReview(var1);
   }

   public boolean isReviewed(UUID var1) {
      return Main.getInstance().getConfig().getBoolean("Settings.mysql")?Main.getDBS().isReviewed(var1):Main.getStatusLog().isReviewed(Bukkit.getPlayer(var1).getName());
   }

   public void setStatusReviewed(String var1, String var2) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         Main.getDBS().setStatus(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var1))?Bukkit.getPlayer(var1).getUniqueId():Bukkit.getOfflinePlayer(var1).getUniqueId(), var2);
      } else {
         Main.getStatusLog().setReviewed(var1, var2);
      }

   }

   public void setStatusOpen(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         Main.getDBS().setStatus(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var1))?Bukkit.getPlayer(var1).getUniqueId():Bukkit.getOfflinePlayer(var1).getUniqueId(), "Open");
      } else {
         Main.getStatusLog().removeReview(var1);
      }

   }

   public String getReviewer(UUID var1) {
      return Main.getInstance().getConfig().getBoolean("Settings.mysql")?Main.getDBS().getReviewer(var1):Main.getStatusLog().getStaffer(Bukkit.getPlayer(var1).getName());
   }

   public String getTarget(String var1) {
      return Main.getInstance().getConfig().getBoolean("Settings.mysql")?Main.getDBS().getTarget(var1):Main.getStatusLog().getTarget(var1);
   }

   public void removeReviewBy(String var1) {
      if(Main.getInstance().getConfig().getBoolean("Settings.mysql")) {
         Main.getDBS().removeStatus(Bukkit.getOnlinePlayers().contains(Bukkit.getPlayer(var1))?Bukkit.getPlayer(var1).getUniqueId():Bukkit.getOfflinePlayer(var1).getUniqueId());
      } else {
         Main.getStatusLog().removeReviewBy(var1);
      }

   }
}
